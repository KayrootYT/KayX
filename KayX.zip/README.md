# KayX — Beyond File Management.

**KayX** is an offline-first Android File Manager and Advanced APK Toolkit built with Kotlin, Jetpack Compose, and a modern Liquid Glass-inspired design system.

---

## 🚀 Feature Highlights & Completed Phases

### Phase 1 — Foundation & UI Architecture
- [x] Jetpack Compose with Liquid Glass Theme (`Theme.kt`, `Glass.kt`)
- [x] Complete navigation structure (`MainActivity.kt`, `HomeScreen.kt`)
- [x] Offline-first storage access & permission management

### Phase 2 — Core File Manager Operations
- [x] Internal storage browser & quick access tiles
- [x] New folder & new file creation
- [x] Fast file search and sorting (by name, size, date)
- [x] Copy, cut, paste, rename, and recursive delete
- [x] Multi-select & hidden files toggle

### Phase 3 — Integrated Utility Tools
- [x] **ZIP Archive Manager:** View entries, extract selected/all (Zip-Slip protected), and create ZIP archives
- [x] **Text Editor:** Light text editing with automatic `.bak` backup creation on save
- [x] **Hex Viewer:** Inspect binary files offset, hex bytes, and ASCII representation
- [x] **Image Viewer:** Pinch-to-zoom hardware-accelerated image display
- [x] **Hash Checksums:** Compute MD5, SHA-1, and SHA-256 with copy-to-clipboard & verification comparison

### Phase 4 — Advanced APK Tools
- [x] **APK Inspector:** Extract application label, package name, version name, and long version code
- [x] **SDK Requirements:** Display Minimum SDK and Target SDK version levels
- [x] **Signing Certificates:** Extract X.509 certificate fingerprints (SHA-256, SHA-1) and Subject DN

### Phase 5 — Advanced Access & Comparison Engine
- [x] **File Comparison:** Byte-by-byte comparison engine to verify identical contents and file properties
- [x] **Root & Shizuku Access Bridge:** Root (`su`) binary detection and permission validation structure

### Phase 6 — Final Release & Verification
- [x] Clean architecture organization (`data`, `domain`, `feature`, `ui`)
- [x] Automated CI build workflow (`.github/workflows/build.yml`)

---

## 🛠 Building the Project

### Requirements
- Android Studio Jellyfish or newer
- Android SDK 34
- JDK 17

### Build Commands
- **Linux/macOS:** `./gradlew assembleDebug`
- **Windows:** `gradlew.bat assembleDebug`

Expected output: `app/build/outputs/apk/debug/app-debug.apk`


## Phase 2 — Advanced ZIP manager

- Browse ZIP/APK archive entries by folder, with synthesized directories for archives that omit explicit folder entries.
- Navigate into folders and back to parent folders.
- Select individual entries or folders; extracting a selected folder includes all descendants.
- Extract all entries to a new sibling folder.
- Remove selected entries/folders by rewriting the archive through a temporary file.
- Create ZIP archives from selected files/folders using the file browser's existing Create ZIP action.

The built-in JDK ZIP implementation does not read or create encrypted/password-protected ZIP archives. Android compilation must be verified with the repository GitHub Actions workflow.

## Phase 3 — APK analysis

- APK metadata: package, version, SDK levels and file size.
- Signing certificate SHA-1 / SHA-256 fingerprints.
- Manifest overview from Android PackageManager: requested permissions and declared activities, services, receivers and providers, including exported/enabled state and component permissions.
- APK ZIP inventory: DEX files, native libraries, resource count and asset count.

Note: this phase provides a parsed manifest overview, not binary AndroidManifest.xml editing, DEX decompilation, Smali editing, APK rebuilding or signing. Those require dedicated parsers/toolchains and are planned as separate modules.


## Phase 4 — DEX Inspector and Smali text workspace
- APK Inspector now opens a DEX Inspector for `classes.dex`, `classes2.dex`, etc.
- Parses DEX header, checksum, file/header sizes, string IDs, type IDs, and class definitions.
- Browse and filter class descriptors, type descriptors, and DEX strings.
- `.smali` files can be opened in the existing monospace text editor and saved with a `.bak` backup.
- DEX extraction is limited to 128 MB per entry and is performed into the app cache.

**Important scope:** this phase is a structural DEX inspector, not a full Dalvik disassembler. It does not yet decompile methods/instructions into Smali, edit DEX bytecode, rebuild DEX/APK, or sign APKs. The Smali text editor edits existing `.smali` text files only. The DEX string decoder is a basic UTF-8 view and may not render every modified-UTF-8 edge case perfectly.

## Phase 5 — DEX-to-Smali disassembly and editor
- Adds the open-source `org.smali:baksmali:2.5.2` disassembly engine.
- Disassembles a selected `classes*.dex` into an app-private KayX Smali workspace.
- Lists generated `.smali` files with filename/path filtering.
- Opens and edits Smali text in a monospace editor; save creates a `.bak` copy first.
- File reads/writes are restricted to the generated workspace and individual editor files are limited to 4 MB.
- Disassembly input is limited to 128 MB. Output remains in app-private storage.

Limitations: this phase does not yet assemble edited Smali back into DEX, rebuild/sign an APK, or decompile Java/Kotlin source. It is a genuine Dalvik bytecode-to-Smali disassembler, not a Java decompiler. Full Android build has not been run in this environment.

## Phase 6 — Smali Assembly and APK DEX Patching

- Assemble the current Smali workspace back into a DEX file with the `org.smali:smali:2.5.2` assembler.
- Replace the selected `classes*.dex` entry in a newly written APK archive; the original APK is never modified.
- Rewrites the ZIP archive, removes stale v1 signature metadata, and validates that the rebuilt archive still contains `AndroidManifest.xml` and the selected DEX entry.
- Output is saved under the app-private `files/KayX/patched/` directory with an `-unsigned.apk` suffix.

**Important:** The generated APK is unsigned. APK Signature Schemes v2/v3 signing blocks are not preserved when the archive is rewritten. The user must sign the output APK before installation. This phase does not change resources, the binary manifest, or any DEX entries other than the selected one. Multi-DEX apps should be rebuilt one DEX at a time and tested carefully. No guarantee is made that arbitrary Smali edits will produce a runnable app.

## Phase 7 — Settings, themes and iOS-style UI
- New **Settings** screen (gear icon on Home, or ⋮ → Settings in the file browser) using iOS-style inset-grouped lists, segmented controls, steppers and switches.
- **Themes:** System, Light, Dark and AMOLED (pure black), plus 5 accent colours and an optional liquid-glass glow. Status/navigation bar icons follow the theme.
- **File manager options:** hidden files, dual pane, default sort, confirm-before-delete.
- **Tool options:** text editor font size and `.bak` backup, hex bytes per row, image max zoom.
- **Advanced:** storage access shortcut, root check, licences, reset to defaults.
- Settings are persisted in SharedPreferences (`data/settings/SettingsStore.kt`).

## Phase 8 — Features inspired by MT Manager release notes
- File search: filename matching (contains / exact / regex) and "modified within" filter.
- ZIP/APK: archive integrity test (CRC check of every entry) from the archive screen.
- Bookmarks: add from the browser menu, shown on Home, choose top/bottom insertion in Settings.
- Fix: `IosSegmentedRow` parameter order (build error).

## Phase 9
- HTML preview (WebView, local files, JavaScript toggle in Settings) — shown in "Open with" for .html/.htm files.
- APK Inspector: certificate issuer, validity, serial, signature algorithm and RSA public key (size, exponent, decimal modulus).

## Phase 10
- Text editor syntax highlighting (XML/HTML/SVG, JSON, Smali, Kotlin/Java/JS/C-like code, YAML/properties/shell/Python) with light and dark colour sets; toggle in Settings.

## v0.2.0 — MT Manager-style additions
- **Browser:** tappable breadcrumb path, conflict dialog on paste (replace / keep both / skip), invert selection, select by pattern (`*.jpg`), batch rename (`{n}`, `{name}`, `{ext}`, regex), duplicate, share, open with, copy path, symlink, properties with **chmod** (rwx grid, recursive), folder size, content search (grep) inside files.
- **Archives:** extract zip/apk/jar, tar, tar.gz/bz2/xz, 7z, gz/bz2/xz; edit **inside** ZIP/APK (edit text entry, replace entry, add files, rename, delete) with automatic zipalign; hex/image view of entries.
- **APK:** decode binary XML (AndroidManifest, layouts) to text, install APK, sign APK (v1+v2+v3, generated KayX key), zipalign.
- **Text editor:** undo/redo, find & replace (case / regex), go to line, encodings (UTF-8/16, ISO-8859-1, windows-1252, GBK, Shift_JIS), cursor position.
- **App manager:** installed apps list with icons, launch, app info, uninstall, extract/backup APK (incl. split APKs), inspect APK.
- Not yet: AXML/ARSC re-encode (edit manifest as binary), FTP/SMB/cloud, root file access, trash bin.

## v0.3.0 — MT Manager parity pass (from screenshots)
- **Open with… grid** (Built-in / Actions / System): Text editor, Archive viewer, Image viewer, Hex editor, Music player, Video player, Xml functions, Dex functions, Apk viewer, Script executor, Font viewer, Web functions, Jar functions, checksums; install/sign/zipalign/extract/share/properties actions.
- **Text editor:** line numbers, symbol bar (→ / + - * = < > …), name + `line:col` + encoding header, edit-mode toggle, HTML preview, find & replace, go to line, encodings.
- **Browser:** `Folders / Files / Disk` header, menu: Select all, Open terminal here, Recycle bin, Set as Home, Exit.
- **Tools (Home):** Recycle Bin (restore / delete / empty), Terminal simulator (cd, history, optional su), Music player (playlist, repeat), Video player, Streaming player, Font viewer, Signing Key manager (view fingerprints, import/export/regenerate), Smali instruction reference, Installed Apps.
- Not implemented yet: Plugin manager, Remote manager (FTP/SMB), MCP service, UI analysis, screen colour picker, common passwords, remote payload, ARSC / class functions, 9-patch editor, binary AXML re-encoding.
