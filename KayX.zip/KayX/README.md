# KayX — Beyond File Management.

**KayX** is an offline-first Android File Manager and Advanced APK Toolkit built with Kotlin, Jetpack Compose, and a modern Liquid Glass-inspired design system.

---

## 🚀 Feature Highlights & Completed Phases

### Phase 1 — Foundation & UI Architecture
- [x] Jetpack Compose with Liquid Glass Theme (`Theme.kt`, `Glass.kt`)
- [x] Complete navigation structure (`MainActivity.kt`, `HomeScreen.kt`)
- [x] Offline-first storage access & permission management

### Phase 2 — Core File Manager Operations
- [x] Internal storage browser & quick access tiles
- [x] New folder & new file creation
- [x] Fast file search and sorting (by name, size, date)
- [x] Copy, cut, paste, rename, and recursive delete
- [x] Multi-select & hidden files toggle

### Phase 3 — Integrated Utility Tools
- [x] **ZIP Archive Manager:** View entries, extract selected/all (Zip-Slip protected), and create ZIP archives
- [x] **Text Editor:** Light text editing with automatic `.bak` backup creation on save
- [x] **Hex Viewer:** Inspect binary files offset, hex bytes, and ASCII representation
- [x] **Image Viewer:** Pinch-to-zoom hardware-accelerated image display
- [x] **Hash Checksums:** Compute MD5, SHA-1, and SHA-256 with copy-to-clipboard & verification comparison

### Phase 4 — Advanced APK Tools
- [x] **APK Inspector:** Extract application label, package name, version name, and long version code
- [x] **SDK Requirements:** Display Minimum SDK and Target SDK version levels
- [x] **Signing Certificates:** Extract X.509 certificate fingerprints (SHA-256, SHA-1) and Subject DN

### Phase 5 — Advanced Access & Comparison Engine
- [x] **File Comparison:** Byte-by-byte comparison engine to verify identical contents and file properties
- [x] **Root & Shizuku Access Bridge:** Root (`su`) binary detection and permission validation structure

### Phase 6 — Final Release & Verification
- [x] Clean architecture organization (`data`, `domain`, `feature`, `ui`)
- [x] Automated CI build workflow (`.github/workflows/build.yml`)

---

## 🛠 Building the Project

### Requirements
- Android Studio Jellyfish or newer
- Android SDK 34
- JDK 17

### Build Commands
- **Linux/macOS:** `./gradlew assembleDebug`
- **Windows:** `gradlew.bat assembleDebug`

Expected output: `app/build/outputs/apk/debug/app-debug.apk`
