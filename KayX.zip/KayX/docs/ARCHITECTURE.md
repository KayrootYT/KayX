# Architecture

Clean Architecture with UI, Domain, Data, and Core layers.