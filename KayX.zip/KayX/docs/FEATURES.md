# Features

File Manager, APK Tools, Archive Manager, and Developer Tools.