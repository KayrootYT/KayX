# Security Guidelines

Zip-slip protection, safe deletion, and secure parsing.