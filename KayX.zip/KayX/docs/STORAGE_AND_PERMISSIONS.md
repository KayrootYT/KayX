# Storage and Permissions

Offline-first SAF and Storage Access permissions.