package com.kayx.manager.feature.filebrowser

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.kayx.manager.domain.model.FileItem
import com.kayx.manager.domain.model.SortBy
import com.kayx.manager.domain.model.Tool
import com.kayx.manager.ui.glass.GlassCard
import com.kayx.manager.ui.glass.glassBackground
import com.kayx.manager.ui.theme.Accent
import java.text.DateFormat
import java.util.Date

private sealed interface Dlg {
    data object NewFolder : Dlg
    data object NewFile : Dlg
    data class Rename(val path: String, val name: String) : Dlg
    data object Delete : Dlg
    data object Zip : Dlg
}

private fun fmtSize(b: Long): String {
    if (b < 1024) return "$b B"
    val u = arrayOf("KB", "MB", "GB", "TB"); var v = b / 1024.0; var i = 0
    while (v >= 1024 && i < u.lastIndex) { v /= 1024; i++ }
    return "%.1f %s".format(v, u[i])
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FileBrowserScreen(startPath: String, onExit: () -> Unit, onOpenFile: (String, Tool) -> Unit, vm: FileBrowserViewModel = viewModel()) {
    val s by vm.state.collectAsStateWithLifecycle()
    var dlg by remember { mutableStateOf<Dlg?>(null) }
    var menu by remember { mutableStateOf(false) }
    var openFor by remember { mutableStateOf<FileItem?>(null) }
    val snack = remember { SnackbarHostState() }
    LaunchedEffect(startPath) { vm.start(startPath) }
    LaunchedEffect(s.message) { s.message?.let { snack.showSnackbar(it); vm.consumeMessage() } }
    BackHandler { if (!vm.up()) onExit() }

    Scaffold(
        modifier = Modifier.glassBackground(), containerColor = Color.Transparent,
        snackbarHost = { SnackbarHost(snack) },
        floatingActionButton = {
            if (s.selected.isEmpty() && s.clipboard.isEmpty()) Column(horizontalAlignment = Alignment.End, verticalArrangement = Arrangement.spacedBy(10.dp)) {
                SmallFloatingActionButton(onClick = { dlg = Dlg.NewFile }, containerColor = Color.White.copy(.15f)) { Icon(Icons.Default.NoteAdd, null) }
                FloatingActionButton(onClick = { dlg = Dlg.NewFolder }, containerColor = Accent) { Icon(Icons.Default.CreateNewFolder, null, tint = Color.Black) }
            }
        },
        topBar = {
            GlassCard(Modifier.statusBarsPadding().padding(12.dp).fillMaxWidth()) {
                Row(Modifier.padding(horizontal = 6.dp, vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                    IconButton({ if (!vm.up()) onExit() }) { Icon(Icons.Default.ArrowBack, null) }
                    if (s.searching) TextField(
                        s.query, vm::setQuery, Modifier.weight(1f), singleLine = true, placeholder = { Text("Search in folder") },
                        colors = TextFieldDefaults.colors(focusedContainerColor = Color.Transparent, unfocusedContainerColor = Color.Transparent,
                            focusedIndicatorColor = Color.Transparent, unfocusedIndicatorColor = Color.Transparent))
                    else Column(Modifier.weight(1f)) {
                        Text(if (s.selected.isEmpty()) s.dir.substringAfterLast('/').ifEmpty { "/" } else "${s.selected.size} selected", maxLines = 1, style = MaterialTheme.typography.titleMedium)
                        Text(s.dir, maxLines = 1, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.bodySmall, color = Color.White.copy(.6f))
                    }
                    if (s.selected.isEmpty()) {
                        IconButton(vm::toggleSearch) { Icon(if (s.searching) Icons.Default.Close else Icons.Default.Search, null) }
                        Box {
                            IconButton({ menu = true }) { Icon(Icons.Default.MoreVert, null) }
                            DropdownMenu(menu, { menu = false }) {
                                DropdownMenuItem({ Text(if (s.showHidden) "Hide hidden files" else "Show hidden files") }, { vm.toggleHidden(); menu = false })
                                SortBy.values().forEach { b -> DropdownMenuItem({ Text("Sort: ${b.name.lowercase()}" + if (s.sort == b) "  ✓" else "") }, { vm.setSort(b); menu = false }) }
                            }
                        }
                    } else {
                        IconButton(vm::selectAll) { Icon(Icons.Default.SelectAll, null) }
                        IconButton(vm::clearSelection) { Icon(Icons.Default.Close, null) }
                    }
                }
            }
        },
        bottomBar = {
            if (s.selected.isNotEmpty()) GlassCard(Modifier.navigationBarsPadding().padding(12.dp).fillMaxWidth()) {
                Row(Modifier.fillMaxWidth().padding(4.dp), horizontalArrangement = Arrangement.SpaceEvenly) {
                    IconButton({ vm.copySelected(false) }) { Icon(Icons.Default.ContentCopy, null) }
                    IconButton({ vm.copySelected(true) }) { Icon(Icons.Default.ContentCut, null) }
                    IconButton({ dlg = Dlg.Zip }) { Icon(Icons.Default.Archive, null) }
                    if (s.selected.size == 1) IconButton({ val p = s.selected.first(); dlg = Dlg.Rename(p, p.substringAfterLast('/')) }) { Icon(Icons.Default.Edit, null) }
                    IconButton({ dlg = Dlg.Delete }) { Icon(Icons.Default.Delete, null, tint = Color(0xFFFF6B6B)) }
                }
            } else if (s.clipboard.isNotEmpty()) GlassCard(Modifier.navigationBarsPadding().padding(12.dp).fillMaxWidth()) {
                Row(Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text("${s.clipboard.size} item(s) ${if (s.cut) "to move" else "to copy"}", Modifier.weight(1f))
                    TextButton(vm::clearClipboard) { Text("Cancel") }
                    Button(vm::paste) { Icon(Icons.Default.ContentPaste, null); Spacer(Modifier.width(6.dp)); Text("Paste") }
                }
            }
        }
    ) { pad ->
        if (s.items.isEmpty() && !s.loading) Box(Modifier.fillMaxSize().padding(pad), Alignment.Center) { Text("Empty", color = Color.White.copy(.5f)) }
        LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(12.dp, pad.calculateTopPadding() + 4.dp, 12.dp, pad.calculateBottomPadding() + 90.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(s.items, key = { it.path }) { f ->
                FileRow(f, f.path in s.selected,
                    onClick = { if (s.selected.isNotEmpty()) vm.toggleSelect(f.path) else if (f.isDir) vm.open(f.path) else openFor = f },
                    onLong = { vm.toggleSelect(f.path) })
            }
        }
    }

    when (val d = dlg) {
        is Dlg.NewFolder -> NameDialog("New folder", "", { dlg = null }) { vm.newFolder(it); dlg = null }
        is Dlg.NewFile -> NameDialog("New file", "", { dlg = null }) { vm.newFile(it); dlg = null }
        is Dlg.Rename -> NameDialog("Rename", d.name, { dlg = null }) { vm.rename(d.path, it); dlg = null }
        is Dlg.Zip -> NameDialog("Create ZIP", "archive.zip", { dlg = null }) { vm.zipSelected(it); dlg = null }
        is Dlg.Delete -> AlertDialog({ dlg = null }, title = { Text("Delete ${s.selected.size} item(s)?") }, text = { Text("This cannot be undone.") },
            confirmButton = { TextButton({ vm.deleteSelected(); dlg = null }) { Text("Delete", color = Color(0xFFFF6B6B)) } },
            dismissButton = { TextButton({ dlg = null }) { Text("Cancel") } })
        null -> {}
    }
    openFor?.let { f ->
        AlertDialog({ openFor = null }, title = { Text(f.name, maxLines = 1, overflow = TextOverflow.Ellipsis) },
            text = {
                Column {
                    listOf("APK Inspector" to Tool.APK, "Text editor" to Tool.TEXT, "Hex viewer" to Tool.HEX, "Image viewer" to Tool.IMAGE, "ZIP / APK contents" to Tool.ZIP, "Checksums" to Tool.CHECKSUM).forEach { (l, t) ->
                        TextButton({ openFor = null; onOpenFile(f.path, t) }, Modifier.fillMaxWidth()) { Text(l) }
                    }
                }
            },
            confirmButton = {}, dismissButton = { TextButton({ openFor = null }) { Text("Cancel") } })
    }
}

@Composable
private fun FileRow(f: FileItem, selected: Boolean, onClick: () -> Unit, onLong: () -> Unit) {
    GlassCard(Modifier.fillMaxWidth(), tint = if (selected) Accent else Color.White, onClick = onClick, onLongClick = onLong) {
        Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(if (selected) Icons.Default.CheckCircle else if (f.isDir) Icons.Default.Folder else Icons.Default.InsertDriveFile, null,
                tint = if (f.isDir || selected) Accent else Color.White.copy(.75f), modifier = Modifier.size(28.dp))
            Spacer(Modifier.width(14.dp))
            Column(Modifier.weight(1f)) {
                Text(f.name, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text((if (f.isDir) "Folder" else fmtSize(f.size)) + "  •  " + DateFormat.getDateInstance(DateFormat.MEDIUM).format(Date(f.modified)),
                    style = MaterialTheme.typography.bodySmall, color = Color.White.copy(.55f))
            }
        }
    }
}

@Composable
private fun NameDialog(title: String, initial: String, onDismiss: () -> Unit, onOk: (String) -> Unit) {
    var t by remember { mutableStateOf(initial) }
    AlertDialog(onDismiss, title = { Text(title) }, text = { OutlinedTextField(t, { t = it }, singleLine = true) },
        confirmButton = { TextButton({ onOk(t) }) { Text("OK") } }, dismissButton = { TextButton(onDismiss) { Text("Cancel") } })
}
