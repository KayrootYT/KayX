package com.kayx.manager.domain.model

enum class Tool { TEXT, HEX, IMAGE, ZIP, CHECKSUM, APK, COMPARE }
