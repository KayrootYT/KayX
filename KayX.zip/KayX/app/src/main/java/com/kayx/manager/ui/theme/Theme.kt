package com.kayx.manager.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

// KayX Liquid Glass palette: cool blue glass over a deep AMOLED canvas.
val Accent = Color(0xFF76A9FF)
val Accent2 = Color(0xFF9B83FF)
val Bg = Color(0xFF080D18)
val GlassSurface = Color(0xFF111B2B)
val TextPrimary = Color(0xFFF3F7FF)
val TextMuted = Color(0xFF9AAAC2)

@Composable
fun KayXTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Accent,
            onPrimary = Color(0xFF06101F),
            secondary = Accent2,
            background = Bg,
            surface = GlassSurface,
            onSurface = TextPrimary,
            onBackground = TextPrimary,
            surfaceVariant = Color(0xFF1A2940),
            onSurfaceVariant = TextMuted
        ),
        content = content
    )
}
