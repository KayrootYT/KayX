package com.kayx.manager.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val Accent = Color(0xFF7C9CFF)
val Accent2 = Color(0xFFB26BFF)
val Bg = Color(0xFF05070D)

@Composable
fun KayXTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Accent, secondary = Accent2,
            background = Bg, surface = Bg, onSurface = Color.White, onBackground = Color.White
        ),
        content = content
    )
}
