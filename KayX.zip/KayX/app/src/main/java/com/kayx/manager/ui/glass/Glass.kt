package com.kayx.manager.ui.glass

import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.unit.dp
import com.kayx.manager.ui.theme.Accent
import com.kayx.manager.ui.theme.Accent2
import com.kayx.manager.ui.theme.Bg

/** Dark backdrop with soft light blobs so glass layers have something to refract. */
fun Modifier.glassBackground(): Modifier = this
    .background(Bg)
    .drawBehind {
        drawRect(Brush.radialGradient(listOf(Accent.copy(alpha = .35f), Color.Transparent),
            center = Offset(size.width * .15f, size.height * .1f), radius = size.width * .8f))
        drawRect(Brush.radialGradient(listOf(Accent2.copy(alpha = .28f), Color.Transparent),
            center = Offset(size.width * .95f, size.height * .75f), radius = size.width * .9f))
    }

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun GlassCard(
    modifier: Modifier = Modifier,
    shape: Shape = RoundedCornerShape(22.dp),
    tint: Color = Color.White,
    onClick: (() -> Unit)? = null,
    onLongClick: (() -> Unit)? = null,
    content: @Composable BoxScope.() -> Unit
) {
    val base = modifier
        .clip(shape)
        .background(Brush.verticalGradient(listOf(tint.copy(alpha = .16f), tint.copy(alpha = .05f))))
        .border(1.dp, Brush.linearGradient(listOf(Color.White.copy(alpha = .55f), Color.White.copy(alpha = .06f), Color.White.copy(alpha = .22f))), shape)
    val m = if (onClick != null || onLongClick != null)
        base.combinedClickable(onClick = { onClick?.invoke() }, onLongClick = onLongClick) else base
    Box(m, content = content)
}
