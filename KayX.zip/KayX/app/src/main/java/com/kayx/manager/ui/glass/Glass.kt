package com.kayx.manager.ui.glass

import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.unit.dp
import com.kayx.manager.ui.theme.Accent
import com.kayx.manager.ui.theme.Accent2
import com.kayx.manager.ui.theme.Bg

/** Layered luminous backdrop gives translucent surfaces a liquid-glass feel. */
fun Modifier.glassBackground(): Modifier = this
    .background(Bg)
    .drawBehind {
        drawRect(Brush.linearGradient(listOf(Color(0xFF0B1424), Bg, Color(0xFF101027))))
        drawRect(Brush.radialGradient(listOf(Accent.copy(alpha = .24f), Color.Transparent),
            center = Offset(size.width * .04f, size.height * .08f), radius = size.width * .92f))
        drawRect(Brush.radialGradient(listOf(Accent2.copy(alpha = .19f), Color.Transparent),
            center = Offset(size.width * .98f, size.height * .68f), radius = size.width * .82f))
        drawRect(Brush.radialGradient(listOf(Color.White.copy(alpha = .035f), Color.Transparent),
            center = Offset(size.width * .52f, size.height * .42f), radius = size.width * .7f))
    }

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun GlassCard(
    modifier: Modifier = Modifier,
    shape: Shape = RoundedCornerShape(18.dp),
    tint: Color = Color.White,
    onClick: (() -> Unit)? = null,
    onLongClick: (() -> Unit)? = null,
    content: @Composable BoxScope.() -> Unit
) {
    val base = modifier
        .clip(shape)
        .background(Brush.verticalGradient(listOf(
            tint.copy(alpha = .155f),
            Color(0xFF17243A).copy(alpha = .20f),
            tint.copy(alpha = .055f)
        )))
        .border(1.dp, Brush.linearGradient(listOf(
            Color.White.copy(alpha = .42f),
            Accent.copy(alpha = .13f),
            Color.White.copy(alpha = .055f),
            Accent2.copy(alpha = .20f)
        )), shape)
    val m = if (onClick != null || onLongClick != null)
        base.combinedClickable(onClick = { onClick?.invoke() }, onLongClick = onLongClick)
    else base
    Box(m, content = content)
}
