package com.kayx.manager.data.filesystem

import com.kayx.manager.domain.model.FileItem
import com.kayx.manager.domain.model.SortBy
import java.io.File
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class FileRepository {

    suspend fun list(dir: File, showHidden: Boolean = false, sort: SortBy = SortBy.NAME): List<FileItem> = withContext(Dispatchers.IO) {
        if (!dir.exists() || !dir.isDirectory) return@withContext emptyList()
        val files = dir.listFiles() ?: return@withContext emptyList()
        
        files.asSequence()
            .filter { showHidden || !it.isHidden }
            .map { f ->
                FileItem(
                    path = f.absolutePath,
                    name = f.name,
                    isDir = f.isDirectory,
                    size = if (f.isFile) f.length() else 0L,
                    modified = f.lastModified(),
                    hidden = f.isHidden
                )
            }
            .sortedWith { a, b ->
                if (a.isDir != b.isDir) return@sortedWith if (a.isDir) -1 else 1
                when (sort) {
                    SortBy.NAME -> a.name.compareTo(b.name, ignoreCase = true)
                    SortBy.SIZE -> b.size.compareTo(a.size)
                    SortBy.DATE -> b.modified.compareTo(a.modified)
                }
            }
            .toList()
    }

    suspend fun search(dir: File, query: String, showHidden: Boolean = false): List<FileItem> = withContext(Dispatchers.IO) {
        if (!dir.exists() || !dir.isDirectory || query.isBlank()) return@withContext emptyList()
        
        dir.walkTopDown()
            .maxDepth(4)
            .filter { showHidden || !it.isHidden }
            .filter { it.name.contains(query, ignoreCase = true) }
            .map { f ->
                FileItem(
                    path = f.absolutePath,
                    name = f.name,
                    isDir = f.isDirectory,
                    size = if (f.isFile) f.length() else 0L,
                    modified = f.lastModified(),
                    hidden = f.isHidden
                )
            }
            .toList()
    }

    suspend fun createFolder(parent: File, name: String): Result<Unit> = withContext(Dispatchers.IO) {
        runCatching {
            val folder = File(parent, name)
            check(!folder.exists()) { "Folder already exists" }
            check(folder.mkdirs()) { "Could not create folder" }
        }
    }

    suspend fun createFile(parent: File, name: String): Result<Unit> = withContext(Dispatchers.IO) {
        runCatching {
            val file = File(parent, name)
            check(!file.exists()) { "File already exists" }
            check(file.createNewFile()) { "Could not create file" }
        }
    }

    suspend fun delete(files: List<File>): Result<Unit> = withContext(Dispatchers.IO) {
        runCatching {
            for (f in files) {
                if (f.exists()) f.deleteRecursively()
            }
        }
    }

    suspend fun rename(file: File, newName: String): Result<Unit> = withContext(Dispatchers.IO) {
        runCatching {
            val dest = File(file.parentFile, newName)
            check(!dest.exists()) { "Target name already exists" }
            check(file.renameTo(dest)) { "Rename failed" }
        }
    }

    suspend fun copy(files: List<File>, targetDir: File): Result<Unit> = withContext(Dispatchers.IO) {
        runCatching {
            for (f in files) {
                val dest = File(targetDir, f.name)
                if (f.isDirectory) f.copyRecursively(dest, overwrite = true)
                else f.copyTo(dest, overwrite = true)
            }
        }
    }

    suspend fun move(files: List<File>, targetDir: File): Result<Unit> = withContext(Dispatchers.IO) {
        runCatching {
            for (f in files) {
                val dest = File(targetDir, f.name)
                if (f.isDirectory) {
                    f.copyRecursively(dest, overwrite = true)
                    f.deleteRecursively()
                } else {
                    f.copyTo(dest, overwrite = true)
                    f.delete()
                }
            }
        }
    }

    suspend fun compareFiles(file1: File, file2: File): ComparisonResult = withContext(Dispatchers.IO) {
        val sameSize = file1.length() == file2.length()
        val sameName = file1.name == file2.name
        var identicalContent = false

        if (sameSize) {
            identicalContent = try {
                file1.inputStream().use { input1 ->
                    file2.inputStream().use { input2 ->
                        val buf1 = ByteArray(64 * 1024)
                        val buf2 = ByteArray(64 * 1024)
                        var equal = true
                        while (equal) {
                            val r1 = input1.read(buf1)
                            val r2 = input2.read(buf2)
                            if (r1 != r2) { equal = false; break }
                            if (r1 == -1) break
                            if (!buf1.copyOf(r1).contentEquals(buf2.copyOf(r2))) {
                                equal = false
                                break
                            }
                        }
                        equal
                    }
                }
            } catch (e: Exception) {
                false
            }
        }

        ComparisonResult(
            file1Name = file1.name,
            file2Name = file2.name,
            file1Size = file1.length(),
            file2Size = file2.length(),
            sameSize = sameSize,
            sameName = sameName,
            identicalContent = identicalContent
        )
    }
}

data class ComparisonResult(
    val file1Name: String,
    val file2Name: String,
    val file1Size: Long,
    val file2Size: Long,
    val sameSize: Boolean,
    val sameName: Boolean,
    val identicalContent: Boolean
)
