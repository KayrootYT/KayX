package com.kayx.manager.feature.filebrowser

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.kayx.manager.data.archive.ArchiveRepository
import com.kayx.manager.data.filesystem.FileRepository
import com.kayx.manager.domain.model.FileItem
import com.kayx.manager.domain.model.SortBy
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

data class BrowserState(
    val root: String = "",
    val dir: String = "",
    val items: List<FileItem> = emptyList(),
    val selected: Set<String> = emptySet(),
    val clipboard: List<String> = emptyList(),
    val cut: Boolean = false,
    val query: String = "",
    val searching: Boolean = false,
    val showHidden: Boolean = false,
    val sort: SortBy = SortBy.NAME,
    val loading: Boolean = false,
    val message: String? = null
)

class FileBrowserViewModel(private val repo: FileRepository = FileRepository(), private val archive: ArchiveRepository = ArchiveRepository()) : ViewModel() {
    private val _s = MutableStateFlow(BrowserState())
    val state: StateFlow<BrowserState> = _s

    /** Start a browsing session at [path] (this becomes the root). */
    fun start(path: String) {
        if (_s.value.root == path) { reload(); return }
        _s.update { it.copy(root = path) }; open(path)
    }

    fun open(path: String) {
        _s.update { it.copy(dir = path, selected = emptySet(), query = "", searching = false) }; reload()
    }

    /** @return false when already at root (caller should leave the browser). */
    fun up(): Boolean {
        val s = _s.value
        if (s.selected.isNotEmpty()) { _s.update { it.copy(selected = emptySet()) }; return true }
        if (s.searching) { _s.update { it.copy(searching = false, query = "") }; reload(); return true }
        if (s.dir == s.root) { _s.update { it.copy(root = "") }; return false }
        File(s.dir).parent?.let { open(it) }; return true
    }

    fun reload() {
        val s = _s.value
        viewModelScope.launch {
            _s.update { it.copy(loading = true) }
            val r = withContext(Dispatchers.IO) {
                if (s.searching && s.query.isNotBlank()) repo.search(File(s.dir), s.query, s.showHidden)
                else repo.list(File(s.dir), s.showHidden, s.sort)
            }
            _s.update { it.copy(items = r, loading = false) }
        }
    }

    fun toggleSearch() { _s.update { it.copy(searching = !it.searching, query = "") }; reload() }
    fun setQuery(q: String) { _s.update { it.copy(query = q) }; reload() }
    fun toggleHidden() { _s.update { it.copy(showHidden = !it.showHidden) }; reload() }
    fun setSort(s: SortBy) { _s.update { it.copy(sort = s) }; reload() }
    fun toggleSelect(path: String) = _s.update { it.copy(selected = if (path in it.selected) it.selected - path else it.selected + path) }
    fun selectAll() = _s.update { it.copy(selected = it.items.map { i -> i.path }.toSet()) }
    fun clearSelection() = _s.update { it.copy(selected = emptySet()) }
    fun consumeMessage() = _s.update { it.copy(message = null) }
    fun copySelected(cut: Boolean) = _s.update { it.copy(clipboard = it.selected.toList(), cut = cut, selected = emptySet(), message = if (cut) "Cut ${it.selected.size}" else "Copied ${it.selected.size}") }
    fun clearClipboard() = _s.update { it.copy(clipboard = emptyList()) }

    private fun run(op: () -> Result<Unit>, ok: String? = null) = viewModelScope.launch {
        val r = withContext(Dispatchers.IO) { op() }
        _s.update { it.copy(selected = emptySet(), message = r.exceptionOrNull()?.message ?: ok) }
        reload()
    }

    fun paste() {
        val s = _s.value; val files = s.clipboard.map(::File); val dst = File(s.dir)
        run({ if (s.cut) repo.move(files, dst) else repo.copy(files, dst) }, "Done")
        if (s.cut) clearClipboard()
    }
    fun newFolder(n: String) = run({ repo.createFolder(File(_s.value.dir), n) })
    fun newFile(n: String) = run({ repo.createFile(File(_s.value.dir), n) })
    fun rename(path: String, n: String) = run({ repo.rename(File(path), n) })
    fun zipSelected(name: String) {
        val f = _s.value.selected.map(::File)
        val n = name.trim().replace('/', '_').ifEmpty { "archive" }.let { if (it.endsWith(".zip", true)) it else "$it.zip" }
        val out = File(_s.value.dir, n)
        run({ archive.create(f, out) }, "Created $n")
    }
    fun deleteSelected() { val f = _s.value.selected.map(::File); run({ repo.delete(f) }, "Deleted ${f.size}") }
}
