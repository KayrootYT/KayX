package com.kayx.manager.data.archive

import java.io.File
import java.util.zip.ZipEntry
import java.util.zip.ZipFile
import java.util.zip.ZipOutputStream

data class ZipItem(val name: String, val size: Long, val compressed: Long, val isDir: Boolean)

class ArchiveRepository {

    fun list(zip: File): List<ZipItem> = ZipFile(zip).use { z ->
        z.entries().asSequence().map { ZipItem(it.name, it.size, it.compressedSize, it.isDirectory) }.toList()
    }

    private fun uniqueDir(dir: File): File {
        var t = dir; var i = 1
        while (t.exists()) { t = File(dir.parentFile, "${dir.name} ($i)"); i++ }
        return t
    }

    /** Extracts into a new folder next to the archive. Blocks zip-slip paths. Returns (folder, fileCount). */
    fun extract(zip: File, names: Set<String>?): Result<Pair<File, Int>> = runCatching {
        val dest = uniqueDir(File(zip.parentFile, zip.nameWithoutExtension))
        check(dest.mkdirs()) { "Could not create output folder" }
        val root = dest.canonicalPath
        var n = 0
        try {
            ZipFile(zip).use { z ->
                for (e in z.entries()) {
                    if (names != null && e.name !in names) continue
                    val out = File(dest, e.name); val c = out.canonicalPath
                    check(c == root || c.startsWith(root + File.separator)) { "Blocked unsafe path: ${e.name}" }
                    if (e.isDirectory) { out.mkdirs(); continue }
                    out.parentFile?.mkdirs()
                    z.getInputStream(e).use { i -> out.outputStream().use { o -> i.copyTo(o) } }
                    n++
                }
            }
        } catch (t: Throwable) { dest.deleteRecursively(); throw t }
        dest to n
    }

    fun create(files: List<File>, out: File): Result<Unit> = runCatching {
        check(!out.exists()) { "${out.name} already exists" }
        try {
            ZipOutputStream(out.outputStream().buffered()).use { zos ->
                for (f in files) {
                    val base = f.parentFile ?: f
                    for (x in f.walkTopDown()) {
                        if (x.canonicalPath == out.canonicalPath) continue
                        val rel = x.relativeTo(base).path.replace(File.separatorChar, '/')
                        if (x.isDirectory) { zos.putNextEntry(ZipEntry("$rel/")); zos.closeEntry() }
                        else { zos.putNextEntry(ZipEntry(rel)); x.inputStream().use { it.copyTo(zos) }; zos.closeEntry() }
                    }
                }
            }
        } catch (t: Throwable) { out.delete(); throw t }
    }
}
