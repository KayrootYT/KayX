package com.kayx.manager.feature.filebrowser

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.kayx.manager.ui.glass.GlassCard
import com.kayx.manager.ui.glass.glassBackground
import com.kayx.manager.ui.theme.Accent

enum class ActivePane { A, B }

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DualBrowserScreen(startPath: String, onExit: () -> Unit, onOpenTool: (String, com.kayx.manager.domain.model.Tool) -> Unit) {
    var activePane by remember { mutableStateOf(ActivePane.A) }
    var pathA by remember { mutableStateOf(startPath) }
    var pathB by remember { mutableStateOf(startPath) }

    BackHandler { onExit() }

    Scaffold(
        modifier = Modifier.glassBackground(),
        containerColor = Color.Transparent,
        topBar = {
            GlassCard(Modifier.statusBarsPadding().padding(12.dp).fillMaxWidth()) {
                Row(Modifier.padding(horizontal = 12.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onExit) { Icon(Icons.Default.ArrowBack, null) }
                    Text("Dual-Window Browser (MT Style)", Modifier.weight(1f), style = MaterialTheme.typography.titleMedium)
                    IconButton(onClick = { activePane = if (activePane == ActivePane.A) ActivePane.B else ActivePane.A }) {
                        Icon(Icons.Default.SwapHoriz, null, tint = Accent)
                    }
                }
            }
        }
    ) { pad ->
        Column(
            Modifier.fillMaxSize().padding(pad).padding(8.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            // Pane A
            Box(Modifier.weight(1f)) {
                GlassCard(Modifier.fillMaxWidth().fillMaxHeight(), tint = if (activePane == ActivePane.A) Accent else Color.White) {
                    Column(Modifier.fillMaxSize()) {
                        Surface(
                            color = if (activePane == ActivePane.A) Accent.copy(alpha = 0.2f) else Color.Transparent,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text("Pane A: $pathA", modifier = Modifier.padding(8.dp), style = MaterialTheme.typography.labelMedium)
                        }
                        Box(Modifier.fillMaxSize()) {
                            FileBrowserScreen(
                                startPath = pathA,
                                onExit = {},
                                onOpenFile = { p, t -> onOpenTool(p, t) }
                            )
                        }
                    }
                }
            }

            Divider(color = Color.White.copy(alpha = 0.2f), thickness = 2.dp)

            // Pane B
            Box(Modifier.weight(1f)) {
                GlassCard(Modifier.fillMaxWidth().fillMaxHeight(), tint = if (activePane == ActivePane.B) Accent else Color.White) {
                    Column(Modifier.fillMaxSize()) {
                        Surface(
                            color = if (activePane == ActivePane.B) Accent.copy(alpha = 0.2f) else Color.Transparent,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text("Pane B: $pathB", modifier = Modifier.padding(8.dp), style = MaterialTheme.typography.labelMedium)
                        }
                        Box(Modifier.fillMaxSize()) {
                            FileBrowserScreen(
                                startPath = pathB,
                                onExit = {},
                                onOpenFile = { p, t -> onOpenTool(p, t) }
                            )
                        }
                    }
                }
            }
        }
    }
}
