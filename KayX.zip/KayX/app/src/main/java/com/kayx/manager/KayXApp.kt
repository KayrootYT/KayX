package com.kayx.manager

import android.app.Application

class KayXApp : Application()
