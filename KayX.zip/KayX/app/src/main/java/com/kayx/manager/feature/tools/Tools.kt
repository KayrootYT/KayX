package com.kayx.manager.feature.tools
import androidx.compose.ui.platform.LocalContext

import android.graphics.BitmapFactory
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Image
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.kayx.manager.data.archive.ArchiveRepository
import com.kayx.manager.data.archive.ZipItem
import com.kayx.manager.data.checksum.ChecksumRepository
import com.kayx.manager.data.checksum.Hashes
import com.kayx.manager.ui.glass.GlassCard
import com.kayx.manager.ui.glass.glassBackground
import com.kayx.manager.ui.theme.Accent
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.io.RandomAccessFile

private fun fmt(b: Long): String {
    if (b < 1024) return "$b B"
    val u = arrayOf("KB", "MB", "GB", "TB"); var v = b / 1024.0; var i = 0
    while (v >= 1024 && i < u.lastIndex) { v /= 1024; i++ }
    return "%.1f %s".format(v, u[i])
}

@Composable
fun ToolScaffold(
    title: String, onBack: () -> Unit, snack: SnackbarHostState? = null,
    actions: @Composable RowScope.() -> Unit = {}, bottomBar: @Composable () -> Unit = {},
    content: @Composable (PaddingValues) -> Unit
) {
    BackHandler(onBack = onBack)
    Scaffold(
        modifier = Modifier.glassBackground(), containerColor = Color.Transparent,
        snackbarHost = { if (snack != null) SnackbarHost(snack) },
        bottomBar = bottomBar,
        topBar = {
            GlassCard(Modifier.statusBarsPadding().padding(12.dp).fillMaxWidth()) {
                Row(Modifier.padding(horizontal = 6.dp, vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onBack) { Icon(Icons.Default.ArrowBack, null) }
                    Text(title, Modifier.weight(1f), maxLines = 1, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.titleMedium)
                    actions()
                }
            }
        }, content = content
    )
}

@Composable
private fun Center(pad: PaddingValues, text: String) =
    Box(Modifier.fillMaxSize().padding(pad), Alignment.Center) { Text(text, color = Color.White.copy(.6f)) }

// ---------------- Text editor ----------------
@Composable
fun TextEditorScreen(path: String, onBack: () -> Unit) {
    val file = remember(path) { File(path) }
    var original by remember { mutableStateOf<String?>(null) }
    var text by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }
    var confirmExit by remember { mutableStateOf(false) }
    val snack = remember { SnackbarHostState() }
    val scope = rememberCoroutineScope()
    LaunchedEffect(path) {
        val r = withContext(Dispatchers.IO) {
            runCatching {
                require(file.length() <= 2_000_000) { "File too large for the text editor (max 2 MB)" }
                val s = file.readText()
                require('\u0000' !in s.take(4096)) { "Looks like a binary file. Use the Hex viewer." }
                s
            }
        }
        r.onSuccess { original = it; text = it }.onFailure { error = it.message }
    }
    val dirty = original != null && text != original
    val back = { if (dirty) confirmExit = true else onBack() }
    ToolScaffold(file.name + if (dirty) " •" else "", back, snack, actions = {
        if (original != null) IconButton(enabled = dirty, onClick = {
            scope.launch {
                val r = withContext(Dispatchers.IO) {
                    runCatching { file.copyTo(File(file.parentFile, file.name + ".bak"), overwrite = true); file.writeText(text) }
                }
                if (r.isSuccess) original = text
                snack.showSnackbar(r.exceptionOrNull()?.message ?: "Saved (backup: ${file.name}.bak)")
            }
        }) { Icon(Icons.Default.Save, null, tint = if (dirty) Accent else Color.White.copy(.3f)) }
    }) { pad ->
        when {
            error != null -> Center(pad, error!!)
            original == null -> Center(pad, "Loading…")
            else -> TextField(
                text, { text = it }, Modifier.fillMaxSize().padding(pad).padding(horizontal = 8.dp),
                textStyle = TextStyle(fontFamily = FontFamily.Monospace, fontSize = 13.sp, color = Color.White),
                colors = TextFieldDefaults.colors(focusedContainerColor = Color.Transparent, unfocusedContainerColor = Color.Transparent,
                    focusedIndicatorColor = Color.Transparent, unfocusedIndicatorColor = Color.Transparent)
            )
        }
    }
    if (confirmExit) AlertDialog({ confirmExit = false }, title = { Text("Discard changes?") },
        confirmButton = { TextButton({ confirmExit = false; onBack() }) { Text("Discard", color = Color(0xFFFF6B6B)) } },
        dismissButton = { TextButton({ confirmExit = false }) { Text("Keep editing") } })
}

// ---------------- Hex viewer ----------------
@Composable
fun HexViewerScreen(path: String, onBack: () -> Unit) {
    val file = remember(path) { File(path) }
    val raf = remember(path) { runCatching { RandomAccessFile(file, "r") }.getOrNull() }
    DisposableEffect(path) { onDispose { runCatching { raf?.close() } } }
    ToolScaffold(file.name, onBack) { pad ->
        if (raf == null || file.length() == 0L) { Center(pad, if (raf == null) "Cannot open file" else "Empty file"); return@ToolScaffold }
        val rows = ((file.length() + 7) / 8).toInt()
        LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(16.dp, pad.calculateTopPadding() + 4.dp, 16.dp, 24.dp)) {
            items(rows) { i ->
                val buf = ByteArray(8)
                val n = runCatching { raf.seek(i * 8L); raf.read(buf) }.getOrDefault(0).coerceAtLeast(0)
                val hex = (0 until 8).joinToString(" ") { if (it < n) "%02X".format(buf[it]) else "  " }
                val ascii = (0 until n).map { val c = buf[it].toInt() and 0xFF; if (c in 32..126) c.toChar() else '.' }.joinToString("")
                Text("%08X  %s  %s".format(i * 8L, hex, ascii), fontFamily = FontFamily.Monospace, fontSize = 12.sp, color = Color.White.copy(.9f))
            }
        }
    }
}

// ---------------- Image viewer ----------------
@Composable
fun ImageViewerScreen(path: String, onBack: () -> Unit) {
    var bmp by remember { mutableStateOf<ImageBitmap?>(null) }
    var failed by remember { mutableStateOf(false) }
    var scale by remember { mutableStateOf(1f) }
    var offset by remember { mutableStateOf(Offset.Zero) }
    LaunchedEffect(path) {
        val r = withContext(Dispatchers.IO) {
            runCatching {
                val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                BitmapFactory.decodeFile(path, o)
                var s = 1
                while (o.outWidth / s > 2048 || o.outHeight / s > 2048) s *= 2
                BitmapFactory.decodeFile(path, BitmapFactory.Options().apply { inSampleSize = s })!!.asImageBitmap()
            }
        }
        r.onSuccess { bmp = it }.onFailure { failed = true }
    }
    ToolScaffold(File(path).name, onBack) { pad ->
        val b = bmp
        when {
            failed -> Center(pad, "Cannot decode image")
            b == null -> Center(pad, "Loading…")
            else -> Image(b, null, Modifier.fillMaxSize().padding(pad)
                .pointerInput(Unit) { detectTransformGestures { _, pan, zoom, _ -> scale = (scale * zoom).coerceIn(1f, 8f); offset = if (scale == 1f) Offset.Zero else offset + pan } }
                .graphicsLayer(scaleX = scale, scaleY = scale, translationX = offset.x, translationY = offset.y),
                contentScale = ContentScale.Fit)
        }
    }
}

// ---------------- Checksums ----------------
@Composable
fun ChecksumScreen(path: String, onBack: () -> Unit) {
    val file = remember(path) { File(path) }
    var h by remember { mutableStateOf<Hashes?>(null) }
    var error by remember { mutableStateOf<String?>(null) }
    var expected by remember { mutableStateOf("") }
    val clip = LocalClipboardManager.current
    LaunchedEffect(path) {
        withContext(Dispatchers.IO) { runCatching { ChecksumRepository().compute(file) } }.onSuccess { h = it }.onFailure { error = it.message }
    }
    ToolScaffold(file.name, onBack) { pad ->
        val r = h
        when {
            error != null -> Center(pad, error!!)
            r == null -> Box(Modifier.fillMaxSize().padding(pad), Alignment.Center) { CircularProgressIndicator(color = Accent) }
            else -> Column(Modifier.fillMaxSize().padding(pad).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text("Size: ${fmt(file.length())}", color = Color.White.copy(.7f))
                listOf("MD5" to r.md5, "SHA-1" to r.sha1, "SHA-256" to r.sha256).forEach { (n, v) ->
                    GlassCard(Modifier.fillMaxWidth(), onClick = { clip.setText(AnnotatedString(v)) }) {
                        Column(Modifier.padding(14.dp)) {
                            Text("$n  (tap to copy)", style = MaterialTheme.typography.labelMedium, color = Accent)
                            Text(v, fontFamily = FontFamily.Monospace, fontSize = 12.sp)
                        }
                    }
                }
                OutlinedTextField(expected, { expected = it }, Modifier.fillMaxWidth(), label = { Text("Paste expected hash to compare") }, singleLine = true)
                val e = expected.trim().lowercase()
                if (e.isNotEmpty()) {
                    val ok = e == r.md5 || e == r.sha1 || e == r.sha256
                    Text(if (ok) "✓ Match" else "✗ No match", color = if (ok) Color(0xFF6BFFA0) else Color(0xFFFF6B6B))
                }
            }
        }
    }
}

// ---------------- ZIP viewer / extractor ----------------
@Composable
fun ZipScreen(path: String, onBack: () -> Unit) {
    val file = remember(path) { File(path) }
    val repo = remember { ArchiveRepository() }
    var items by remember { mutableStateOf<List<ZipItem>?>(null) }
    var error by remember { mutableStateOf<String?>(null) }
    var sel by remember { mutableStateOf(setOf<String>()) }
    var busy by remember { mutableStateOf(false) }
    val snack = remember { SnackbarHostState() }
    val scope = rememberCoroutineScope()
    LaunchedEffect(path) {
        withContext(Dispatchers.IO) { runCatching { repo.list(file) } }.onSuccess { items = it }.onFailure { error = "Not a valid ZIP/APK: ${it.message}" }
    }
    fun extract(names: Set<String>?) = scope.launch {
        busy = true
        val r = withContext(Dispatchers.IO) { repo.extract(file, names) }
        busy = false
        snack.showSnackbar(r.fold({ "Extracted ${it.second} file(s) to ${it.first.name}" }, { it.message ?: "Extraction failed" }))
    }
    ToolScaffold(file.name, onBack, snack, bottomBar = {
        if (items != null) GlassCard(Modifier.navigationBarsPadding().padding(12.dp).fillMaxWidth()) {
            Row(Modifier.fillMaxWidth().padding(10.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedButton({ extract(sel) }, Modifier.weight(1f), enabled = sel.isNotEmpty() && !busy) { Text("Extract ${sel.size}") }
                Button({ extract(null) }, Modifier.weight(1f), enabled = !busy) { Text("Extract all") }
            }
        }
    }) { pad ->
        val list = items
        when {
            error != null -> Center(pad, error!!)
            list == null -> Center(pad, "Loading…")
            else -> LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(12.dp, pad.calculateTopPadding() + 4.dp, 12.dp, pad.calculateBottomPadding() + 8.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                item { Text("${list.size} entries", color = Color.White.copy(.6f), modifier = Modifier.padding(4.dp)) }
                items(list, key = { it.name }) { e ->
                    val on = e.name in sel
                    GlassCard(Modifier.fillMaxWidth(), tint = if (on) Accent else Color.White, onClick = { sel = if (on) sel - e.name else sel + e.name }) {
                        Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                            Icon(if (on) Icons.Default.CheckCircle else if (e.isDir) Icons.Default.Folder else Icons.Default.InsertDriveFile, null, tint = if (on || e.isDir) Accent else Color.White.copy(.7f))
                            Spacer(Modifier.width(12.dp))
                            Column(Modifier.weight(1f)) {
                                Text(e.name, maxLines = 2, overflow = TextOverflow.Ellipsis, fontSize = 14.sp)
                                if (!e.isDir) Text("${fmt(e.size)}  →  ${fmt(e.compressed)}", style = MaterialTheme.typography.bodySmall, color = Color.White.copy(.55f))
                            }
                        }
                    }
                }
            }
        }
    }
}


// ---------------- APK Inspector ----------------
@Composable
fun ApkInspectorScreen(path: String, onBack: () -> Unit) {
    val context = LocalContext.current
    val file = remember(path) { File(path) }
    val repo = remember(context) { com.kayx.manager.data.apk.ApkRepository(context) }
    var apkInfo by remember { mutableStateOf<com.kayx.manager.data.apk.ApkInfo?>(null) }
    var error by remember { mutableStateOf<String?>(null) }
    val clip = LocalClipboardManager.current

    LaunchedEffect(path) {
        withContext(Dispatchers.IO) { repo.getApkInfo(file) }
            .onSuccess { apkInfo = it }
            .onFailure { error = it.message ?: "Failed to inspect APK" }
    }

    ToolScaffold(file.name, onBack) { pad ->
        val info = apkInfo
        when {
            error != null -> Center(pad, error!!)
            info == null -> Box(Modifier.fillMaxSize().padding(pad), Alignment.Center) { CircularProgressIndicator(color = Accent) }
            else -> LazyColumn(
                Modifier.fillMaxSize(),
                contentPadding = PaddingValues(16.dp, pad.calculateTopPadding() + 4.dp, 16.dp, 24.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                item {
                    GlassCard(Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Text(info.appName, style = MaterialTheme.typography.titleLarge, color = Accent)
                            Text(info.packageName, style = MaterialTheme.typography.bodyMedium, color = Color.White.copy(.8f))
                            Text("Version: ${info.versionName} (${info.versionCode})", style = MaterialTheme.typography.bodySmall, color = Color.White.copy(.6f))
                            Text("Size: ${fmt(info.size)}", style = MaterialTheme.typography.bodySmall, color = Color.White.copy(.6f))
                        }
                    }
                }

                item {
                    Text("SDK Requirements", style = MaterialTheme.typography.titleSmall, color = Color.White.copy(.7f))
                }

                item {
                    GlassCard(Modifier.fillMaxWidth()) {
                        Row(Modifier.padding(14.dp).fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Column {
                                Text("Minimum SDK", style = MaterialTheme.typography.labelMedium, color = Color.White.copy(.6f))
                                Text("API ${info.minSdk}", style = MaterialTheme.typography.bodyLarge)
                            }
                            Column {
                                Text("Target SDK", style = MaterialTheme.typography.labelMedium, color = Color.White.copy(.6f))
                                Text("API ${info.targetSdk}", style = MaterialTheme.typography.bodyLarge)
                            }
                        }
                    }
                }

                item {
                    Text("Signing Certificate", style = MaterialTheme.typography.titleSmall, color = Color.White.copy(.7f))
                }

                item {
                    GlassCard(Modifier.fillMaxWidth(), onClick = { clip.setText(AnnotatedString(info.certSha256)) }) {
                        Column(Modifier.padding(14.dp)) {
                            Text("SHA-256 Fingerprint (tap to copy)", style = MaterialTheme.typography.labelMedium, color = Accent)
                            Text(info.certSha256, fontFamily = FontFamily.Monospace, fontSize = 11.sp, color = Color.White.copy(.9f))
                        }
                    }
                }

                item {
                    GlassCard(Modifier.fillMaxWidth(), onClick = { clip.setText(AnnotatedString(info.certSha1)) }) {
                        Column(Modifier.padding(14.dp)) {
                            Text("SHA-1 Fingerprint (tap to copy)", style = MaterialTheme.typography.labelMedium, color = Accent)
                            Text(info.certSha1, fontFamily = FontFamily.Monospace, fontSize = 11.sp, color = Color.White.copy(.9f))
                        }
                    }
                }

                item {
                    GlassCard(Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(14.dp)) {
                            Text("Subject DN", style = MaterialTheme.typography.labelMedium, color = Color.White.copy(.6f))
                            Text(info.certSubject, style = MaterialTheme.typography.bodySmall, color = Color.White.copy(.8f))
                        }
                    }
                }
            }
        }
    }
}


// ---------------- File Comparison ----------------
@Composable
fun FileComparisonScreen(path1: String, path2: String, onBack: () -> Unit) {
    val file1 = remember(path1) { File(path1) }
    val file2 = remember(path2) { File(path2) }
    val repo = remember { com.kayx.manager.data.filesystem.FileRepository() }
    var result by remember { mutableStateOf<com.kayx.manager.data.filesystem.ComparisonResult?>(null) }

    LaunchedEffect(path1, path2) {
        result = repo.compareFiles(file1, file2)
    }

    ToolScaffold("File Comparison", onBack) { pad ->
        val res = result
        when {
            res == null -> Box(Modifier.fillMaxSize().padding(pad), Alignment.Center) { CircularProgressIndicator(color = Accent) }
            else -> Column(
                Modifier.fillMaxSize().padding(pad).padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                GlassCard(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text(if (res.identicalContent) "✓ Files are Identical" else "✗ Files Differ",
                            style = MaterialTheme.typography.titleLarge,
                            color = if (res.identicalContent) Color(0xFF6BFFA0) else Color(0xFFFF6B6B))
                        Text(if (res.identicalContent) "Both files have exact same byte content." else "File contents or sizes do not match.",
                            style = MaterialTheme.typography.bodyMedium, color = Color.White.copy(.7f))
                    }
                }

                Text("Comparison Details", style = MaterialTheme.typography.titleSmall, color = Color.White.copy(.7f))

                GlassCard(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("Property", color = Accent, style = MaterialTheme.typography.labelLarge)
                            Text(res.file1Name, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f, fill = false), style = MaterialTheme.typography.labelMedium)
                        }
                        Divider(color = Color.White.copy(.1f))
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("Size", color = Color.White.copy(.6f))
                            Text(fmt(res.file1Size) + " vs " + fmt(res.file2Size))
                        }
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("Size Match", color = Color.White.copy(.6f))
                            Text(if (res.sameSize) "Match" else "Different", color = if (res.sameSize) Color(0xFF6BFFA0) else Color(0xFFFF6B6B))
                        }
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("Content Match", color = Color.White.copy(.6f))
                            Text(if (res.identicalContent) "Identical" else "Different", color = if (res.identicalContent) Color(0xFF6BFFA0) else Color(0xFFFF6B6B))
                        }
                    }
                }
            }
        }
    }
}
