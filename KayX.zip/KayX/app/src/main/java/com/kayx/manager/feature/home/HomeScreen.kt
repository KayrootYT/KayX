package com.kayx.manager.feature.home

import android.os.Environment
import android.os.StatFs
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.kayx.manager.ui.glass.GlassCard
import com.kayx.manager.ui.glass.glassBackground
import com.kayx.manager.ui.theme.Accent
import com.kayx.manager.ui.theme.Accent2
import com.kayx.manager.ui.theme.TextMuted
import java.io.File

@Composable
fun HomeScreen(onOpen: (String) -> Unit) {
    val root = Environment.getExternalStorageDirectory()
    val stat = StatFs(root.path)
    val total = stat.totalBytes.toDouble().coerceAtLeast(1.0)
    val free = stat.availableBytes.toDouble()
    val used = ((total - free) / total).toFloat().coerceIn(0f, 1f)
    fun gb(v: Double) = "%.1f GB".format(v / (1L shl 30))

    Column(
        Modifier.fillMaxSize().glassBackground().statusBarsPadding()
            .navigationBarsPadding().padding(horizontal = 14.dp, vertical = 10.dp),
        verticalArrangement = Arrangement.spacedBy(13.dp)
    ) {
        // Compact manager-style toolbar
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            GlassCard(shape = RoundedCornerShape(13.dp), modifier = Modifier.size(42.dp)) {
                Box(Modifier.fillMaxSize(), Alignment.Center) {
                    Icon(Icons.Default.FolderCopy, null, tint = Accent, modifier = Modifier.size(23.dp))
                }
            }
            Spacer(Modifier.width(11.dp))
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(1.dp)) {
                Text("KayX", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                Text("File manager", style = MaterialTheme.typography.labelSmall, color = TextMuted)
            }
            IconButton(onClick = { onOpen(root.absolutePath) }) { Icon(Icons.Default.Search, "Browse files", tint = Color.White) }
            IconButton(onClick = { onOpen(root.absolutePath) }) { Icon(Icons.Default.MoreVert, "Open storage", tint = Color.White) }
        }

        // Path / storage panel
        GlassCard(Modifier.fillMaxWidth(), shape = RoundedCornerShape(17.dp), onClick = { onOpen(root.absolutePath) }) {
            Column(Modifier.padding(15.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.PhoneAndroid, null, tint = Accent, modifier = Modifier.size(20.dp))
                    Spacer(Modifier.width(9.dp))
                    Column(Modifier.weight(1f)) {
                        Text("Internal storage", fontWeight = FontWeight.SemiBold)
                        Text("/storage/emulated/0", style = MaterialTheme.typography.labelSmall, color = TextMuted)
                    }
                    Icon(Icons.Default.ChevronRight, null, tint = TextMuted)
                }
                LinearProgressIndicator(
                    progress = { used }, modifier = Modifier.fillMaxWidth().height(6.dp),
                    color = Accent, trackColor = Color.White.copy(.10f)
                )
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("${gb(total - free)} used", style = MaterialTheme.typography.labelSmall, color = TextMuted)
                    Text("${gb(free)} free · ${gb(total)} total", style = MaterialTheme.typography.labelSmall, color = TextMuted)
                }
            }
        }

        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Quick access", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.weight(1f))
            Text("OPEN FOLDER", style = MaterialTheme.typography.labelSmall, color = Accent)
        }
        val dirs = listOf(
            Triple("Download", Icons.Default.Download, Environment.DIRECTORY_DOWNLOADS),
            Triple("DCIM", Icons.Default.PhotoCamera, Environment.DIRECTORY_DCIM),
            Triple("Documents", Icons.Default.Description, Environment.DIRECTORY_DOCUMENTS),
            Triple("Music", Icons.Default.MusicNote, Environment.DIRECTORY_MUSIC),
            Triple("Pictures", Icons.Default.Image, Environment.DIRECTORY_PICTURES),
            Triple("Movies", Icons.Default.Movie, Environment.DIRECTORY_MOVIES)
        )
        dirs.chunked(2).forEach { row ->
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                row.forEach { (name, icon, dir) ->
                    QuickTile(name, icon, Modifier.weight(1f)) {
                        val folder = Environment.getExternalStoragePublicDirectory(dir)
                        folder.mkdirs()
                        onOpen(folder.absolutePath)
                    }
                }
                if (row.size == 1) Spacer(Modifier.weight(1f))
            }
        }
        Spacer(Modifier.weight(1f))
        GlassCard(Modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp), onClick = { onOpen(root.absolutePath) }) {
            Row(Modifier.padding(horizontal = 14.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.FolderOpen, null, tint = Accent2)
                Spacer(Modifier.width(10.dp))
                Text("Browse all files", Modifier.weight(1f), fontWeight = FontWeight.Medium)
                Icon(Icons.Default.ArrowForward, null, tint = TextMuted)
            }
        }
    }
}

@Composable
private fun QuickTile(name: String, icon: ImageVector, modifier: Modifier, onClick: () -> Unit) {
    GlassCard(modifier, shape = RoundedCornerShape(15.dp), onClick = onClick) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 13.dp, vertical = 14.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(icon, null, tint = Accent, modifier = Modifier.size(21.dp))
            Spacer(Modifier.width(10.dp))
            Text(name, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Medium)
        }
    }
}
