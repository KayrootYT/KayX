package com.kayx.manager.feature.home

import android.os.Environment
import android.os.StatFs
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.dp
import com.kayx.manager.ui.glass.GlassCard
import com.kayx.manager.ui.glass.glassBackground
import com.kayx.manager.ui.theme.Accent
import java.io.File

@Composable
fun HomeScreen(onOpen: (String) -> Unit) {
    val root = Environment.getExternalStorageDirectory()
    val st = StatFs(root.path)
    val total = st.totalBytes.toDouble(); val free = st.availableBytes.toDouble()
    val used = ((total - free) / total).toFloat()
    fun gb(v: Double) = "%.1f GB".format(v / (1 shl 30))
    Column(Modifier.fillMaxSize().glassBackground().statusBarsPadding().navigationBarsPadding().padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Text("KayX", style = MaterialTheme.typography.headlineLarge)
        Text("Beyond File Management.", color = Color.White.copy(.6f))
        GlassCard(Modifier.fillMaxWidth(), onClick = { onOpen(root.absolutePath) }) {
            Column(Modifier.padding(18.dp)) {
                Text("Internal storage", style = MaterialTheme.typography.titleMedium)
                Spacer(Modifier.height(10.dp))
                LinearProgressIndicator({ used }, Modifier.fillMaxWidth().height(8.dp), color = Accent, trackColor = Color.White.copy(.12f))
                Spacer(Modifier.height(8.dp))
                Text("${gb(total - free)} used of ${gb(total)}", style = MaterialTheme.typography.bodySmall, color = Color.White.copy(.7f))
            }
        }
        Text("Quick access", style = MaterialTheme.typography.titleSmall, color = Color.White.copy(.7f))
        val dirs = listOf(
            Triple("Downloads", Icons.Default.Download, Environment.DIRECTORY_DOWNLOADS),
            Triple("Camera", Icons.Default.PhotoCamera, Environment.DIRECTORY_DCIM),
            Triple("Documents", Icons.Default.Description, Environment.DIRECTORY_DOCUMENTS),
            Triple("Music", Icons.Default.MusicNote, Environment.DIRECTORY_MUSIC),
        )
        dirs.chunked(2).forEach { row ->
            Row(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                row.forEach { (n, ic, d) ->
                    Tile(n, ic, Modifier.weight(1f)) {
                        val f = Environment.getExternalStoragePublicDirectory(d); f.mkdirs(); onOpen(f.absolutePath)
                    }
                }
            }
        }
    }
}

@Composable
private fun Tile(name: String, icon: ImageVector, modifier: Modifier, onClick: () -> Unit) {
    GlassCard(modifier, onClick = onClick) {
        Column(Modifier.padding(18.dp), horizontalAlignment = Alignment.Start) {
            Icon(icon, null, tint = Accent, modifier = Modifier.size(30.dp)); Spacer(Modifier.height(10.dp)); Text(name)
        }
    }
}
