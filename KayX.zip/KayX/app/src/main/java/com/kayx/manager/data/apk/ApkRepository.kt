package com.kayx.manager.data.apk

import android.content.Context
import android.content.pm.PackageInfo
import android.content.pm.PackageManager
import android.os.Build
import java.io.File
import java.security.MessageDigest
import java.security.cert.CertificateFactory
import java.security.cert.X509Certificate

data class ApkInfo(
    val appName: String,
    val packageName: String,
    val versionName: String,
    val versionCode: Long,
    val minSdk: Int,
    val targetSdk: Int,
    val size: Long,
    val certSha256: String,
    val certSha1: String,
    val certSubject: String
)

class ApkRepository(private val context: Context) {

    fun getApkInfo(apkFile: File): Result<ApkInfo> = runCatching {
        check(apkFile.exists()) { "APK file does not exist" }

        val pm = context.packageManager
        val flags = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            PackageManager.GET_SIGNING_CERTIFICATES
        } else {
            @Suppress("DEPRECATION")
            PackageManager.GET_SIGNATURES
        }

        val pkgInfo: PackageInfo = pm.getPackageArchiveInfo(apkFile.absolutePath, flags)
            ?: error("Failed to parse APK archive info")

        pkgInfo.applicationInfo?.apply {
            sourceDir = apkFile.absolutePath
            publicSourceDir = apkFile.absolutePath
        }

        val appLabel = pkgInfo.applicationInfo?.loadLabel(pm)?.toString() ?: apkFile.nameWithoutExtension
        val verCode = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            pkgInfo.longVersionCode
        } else {
            @Suppress("DEPRECATION")
            pkgInfo.versionCode.toLong()
        }

        val minSdk = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            pkgInfo.applicationInfo?.minSdkVersion ?: 0
        } else 0

        val targetSdk = pkgInfo.applicationInfo?.targetSdkVersion ?: 0

        var certSha256 = "N/A"
        var certSha1 = "N/A"
        var certSubject = "N/A"

        val signatures = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            pkgInfo.signingInfo?.apkContentsSigners
        } else {
            @Suppress("DEPRECATION")
            pkgInfo.signatures
        }

        signatures?.firstOrNull()?.let { sig ->
            runCatching {
                val cf = CertificateFactory.getInstance("X.509")
                val cert = cf.generateCertificate(sig.toByteArray().inputStream()) as X509Certificate
                certSubject = cert.subjectDN.name
                val bytes = cert.encoded
                certSha256 = hashBytes(bytes, "SHA-256")
                certSha1 = hashBytes(bytes, "SHA-1")
            }
        }

        ApkInfo(
            appName = appLabel,
            packageName = pkgInfo.packageName ?: "Unknown",
            versionName = pkgInfo.versionName ?: "1.0",
            versionCode = verCode,
            minSdk = minSdk,
            targetSdk = targetSdk,
            size = apkFile.length(),
            certSha256 = certSha256,
            certSha1 = certSha1,
            certSubject = certSubject
        )
    }

    private fun hashBytes(bytes: ByteArray, algorithm: String): String {
        val digest = MessageDigest.getInstance(algorithm).digest(bytes)
        return digest.joinToString(":") { "%02X".format(it) }
    }
}
