package com.kayx.manager.data.filesystem

import android.os.Environment
import java.io.File

/** Simple recycle bin in /sdcard/.KayXRecycleBin with a tab-separated index (id, original path, deleted time). */
object RecycleBin {
    data class Entry(val id: String, val original: String, val deletedAt: Long, val isDir: Boolean, val size: Long) {
        val name: String get() = original.substringAfterLast('/')
    }

    private fun dir(): File = File(Environment.getExternalStorageDirectory(), ".KayXRecycleBin").apply { mkdirs() }
    private fun index() = File(dir(), "index.tsv")

    private fun move(src: File, dest: File) {
        if (src.renameTo(dest)) return
        if (src.isDirectory) check(src.copyRecursively(dest, overwrite = false)) { "Copy failed: ${src.name}" } else src.copyTo(dest, overwrite = false)
        check(src.deleteRecursively()) { "Could not remove ${src.name}" }
    }

    private fun rawEntries(): List<Triple<String, String, Long>> {
        val f = index()
        if (!f.exists()) return emptyList()
        return f.readLines().mapNotNull { l ->
            val p = l.split('\t')
            if (p.size >= 3) Triple(p[0], p[1], p[2].toLongOrNull() ?: 0L) else null
        }
    }

    private fun writeIndex(list: List<Triple<String, String, Long>>) {
        index().writeText(list.joinToString("") { "${it.first}\t${it.second}\t${it.third}\n" })
    }

    fun list(): List<Entry> {
        val d = dir()
        return rawEntries().filter { File(d, it.first).exists() }.map { (id, path, ts) ->
            val f = File(d, id)
            Entry(id, path, ts, f.isDirectory, if (f.isFile) f.length() else 0L)
        }.sortedByDescending { it.deletedAt }
    }

    fun trash(files: List<File>): Result<Unit> = runCatching {
        val d = dir()
        val added = ArrayList<Triple<String, String, Long>>()
        for (f in files) {
            if (!f.exists()) continue
            val inBin = f.canonicalPath.startsWith(d.canonicalPath)
            if (inBin || f.absolutePath.contains('\t') || f.absolutePath.contains('\n')) {
                check(f.deleteRecursively()) { "Could not delete ${f.name}" }; continue
            }
            val id = System.nanoTime().toString(36) + "_" + f.name.take(60)
            move(f, File(d, id))
            added += Triple(id, f.absolutePath, System.currentTimeMillis())
        }
        if (added.isNotEmpty()) writeIndex(rawEntries() + added)
    }

    fun restore(e: Entry): Result<File> = runCatching {
        val src = File(dir(), e.id)
        check(src.exists()) { "Item no longer in recycle bin" }
        val orig = File(e.original)
        orig.parentFile?.mkdirs()
        val dest = if (orig.exists()) FileOps.uniqueName(orig.parentFile ?: orig, orig.name) else orig
        move(src, dest)
        writeIndex(rawEntries().filter { it.first != e.id })
        dest
    }

    fun purge(e: Entry): Result<Unit> = runCatching {
        File(dir(), e.id).deleteRecursively()
        writeIndex(rawEntries().filter { it.first != e.id })
    }

    fun empty(): Result<Unit> = runCatching {
        dir().listFiles()?.forEach { if (it.name != "index.tsv") it.deleteRecursively() }
        index().delete()
        Unit
    }
}
