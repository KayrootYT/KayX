package com.kayx.manager.feature.filebrowser

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.kayx.manager.data.archive.ArchiveRepository
import android.content.Context
import com.kayx.manager.data.apk.ApkSignRepo
import com.kayx.manager.data.archive.ArchiveEdit
import com.kayx.manager.data.archive.MultiExtract
import com.kayx.manager.data.filesystem.Conflict
import com.kayx.manager.data.filesystem.RecycleBin
import com.kayx.manager.data.filesystem.FileOps
import com.kayx.manager.data.filesystem.FileRepository
import com.kayx.manager.data.settings.SettingsStore
import com.kayx.manager.domain.model.FileItem
import com.kayx.manager.domain.model.SortBy
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.async
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

data class BrowserState(
    val root: String = "",
    val dir: String = "",
    val items: List<FileItem> = emptyList(),
    val primarySelected: Set<String> = emptySet(),
    val secondarySelected: Set<String> = emptySet(),
    val clipboard: List<String> = emptyList(),
    val cut: Boolean = false,
    val query: String = "",
    val searching: Boolean = false,
    val showHidden: Boolean = false,
    val sort: SortBy = SortBy.NAME,
    val loading: Boolean = false,
    val message: String? = null,
    val secondaryDir: String = "",
    val secondaryItems: List<FileItem> = emptyList(),
    val dualPane: Boolean = false,
    val activePane: Int = 0,
    val grep: Boolean = false,
    val conflicts: List<String> = emptyList(),
    val transferProgress: TransferProgress? = null,
    /** false = both panes side by side (MT-style split); true = full-screen panes you swipe between. */
    val tabMode: Boolean = false,
    /** Per-pane folder history (index 0 = left/first tab, 1 = right/second tab). */
    val backStacks: List<List<String>> = listOf(emptyList(), emptyList()),
    val fwdStacks: List<List<String>> = listOf(emptyList(), emptyList()),
    /** Paths that were just copied/moved; shown highlighted (green) until the next navigation. */
    val recent: Set<String> = emptySet(),
    /** A transfer waiting for the user to resolve name conflicts. */
    val pending: PendingTransfer? = null
) {
    /** Selection belongs to the active pane; the two panes never share selection state. */
    val selected: Set<String> get() = if (dualPane && activePane == 1) secondarySelected else primarySelected
    /** Index of the pane that currently receives actions (always 0 in single-pane mode). */
    val activeIdx: Int get() = if (dualPane && activePane == 1) 1 else 0
    /** Folder of the pane that is NOT active: the target of "Copy ->" / "Move ->". */
    val otherDir: String get() = if (activePane == 1) dir else secondaryDir
    val canBack: Boolean get() = backStacks[activeIdx].isNotEmpty()
    val canForward: Boolean get() = fwdStacks[activeIdx].isNotEmpty()
}

data class TransferProgress(val completed: Int, val total: Int, val currentName: String, val moving: Boolean = false) {
    val fraction: Float get() = if (total <= 0) 0f else completed.toFloat() / total
}

/** Files + destination remembered while the conflict dialog is open. [sourcePane] is null for clipboard pastes. */
data class PendingTransfer(val files: List<String>, val dst: String, val cut: Boolean, val sourcePane: Int?, val fromClipboard: Boolean)

internal enum class NavMove { PUSH, BACK, FORWARD }

class FileBrowserViewModel(private val repo: FileRepository = FileRepository(), private val archive: ArchiveRepository = ArchiveRepository()) : ViewModel() {
    private val _s = MutableStateFlow(BrowserState(showHidden = SettingsStore.showHidden, sort = SettingsStore.defaultSort, dualPane = SettingsStore.dualPane, tabMode = SettingsStore.dualTabs))
    private var applied = Triple(SettingsStore.showHidden, SettingsStore.defaultSort, SettingsStore.dualPane)
    val state: StateFlow<BrowserState> = _s

    /** Start a browsing session at [path] (this becomes the root). */
    fun start(path: String) {
        if (_s.value.root == path) { reload(); return }
        _s.update { it.copy(root = path, dir = "", secondaryDir = path, secondaryItems = emptyList(), activePane = 0,
            backStacks = listOf(emptyList(), emptyList()), fwdStacks = listOf(emptyList(), emptyList()), recent = emptySet()) }; open(path)
    }

    fun open(path: String) = navigatePane(0, path, NavMove.PUSH)

    /** Change the folder of one pane and keep that pane's back/forward history. */
    private fun navigatePane(pane: Int, path: String, move: NavMove) {
        _s.update { st ->
            val cur = if (pane == 1) st.secondaryDir else st.dir
            val back = st.backStacks[pane]; val fwd = st.fwdStacks[pane]
            val (nb, nf) = when (move) {
                NavMove.PUSH -> if (cur.isBlank() || cur == path) back to fwd else (back + cur).takeLast(50) to emptyList<String>()
                NavMove.BACK -> back.dropLast(1) to (fwd + cur)
                NavMove.FORWARD -> (back + cur) to fwd.dropLast(1)
            }
            val backs = st.backStacks.toMutableList().also { it[pane] = nb }
            val fwds = st.fwdStacks.toMutableList().also { it[pane] = nf }
            if (pane == 1) st.copy(secondaryDir = path, secondarySelected = emptySet(), activePane = 1, backStacks = backs, fwdStacks = fwds, recent = emptySet())
            else st.copy(dir = path, primarySelected = emptySet(), query = "", searching = false, activePane = 0, backStacks = backs, fwdStacks = fwds, recent = emptySet())
        }
        reload()
    }

    /** Back in the active pane's own folder history (the "<" button). */
    fun goBack() {
        val s = _s.value
        val target = s.backStacks[s.activeIdx].lastOrNull() ?: run { notify("No previous folder"); return }
        navigatePane(s.activeIdx, target, NavMove.BACK)
    }

    /** Forward in the active pane's folder history (the ">" button). */
    fun goForward() {
        val s = _s.value
        val target = s.fwdStacks[s.activeIdx].lastOrNull() ?: run { notify("No next folder"); return }
        navigatePane(s.activeIdx, target, NavMove.FORWARD)
    }

    fun toggleTabMode() {
        val v = !_s.value.tabMode
        SettingsStore.updateDualTabs(v)
        _s.update { it.copy(tabMode = v) }
    }

    /** Re-apply browser defaults only when they were changed in Settings (keeps in-browser toggles otherwise). */
    fun syncDefaults() {
        if (_s.value.tabMode != SettingsStore.dualTabs) _s.update { it.copy(tabMode = SettingsStore.dualTabs) }
        val now = Triple(SettingsStore.showHidden, SettingsStore.defaultSort, SettingsStore.dualPane)
        if (now == applied) return
        applied = now
        _s.update { c -> c.copy(showHidden = now.first, sort = now.second, dualPane = now.third,
            secondaryDir = c.secondaryDir.ifBlank { c.root.ifBlank { c.dir } }) }
        reload()
    }

    fun toggleDualPane() {
        _s.update { current ->
            val enabled = !current.dualPane
            current.copy(dualPane = enabled, activePane = if (enabled) current.activePane else 0, secondaryDir = current.secondaryDir.ifBlank { current.root.ifBlank { current.dir } })
        }
        reload()
    }

    fun setActivePane(pane: Int) { _s.update { it.copy(activePane = pane.coerceIn(0, 1)) } }

    fun openSecondary(path: String) = navigatePane(1, path, NavMove.PUSH)

    fun openActive(path: String) {
        if (_s.value.dualPane && _s.value.activePane == 1) openSecondary(path) else open(path)
    }

    fun swapPanes() {
        _s.update { it.copy(dir = it.secondaryDir, secondaryDir = it.dir, primarySelected = it.secondarySelected, secondarySelected = it.primarySelected,
            backStacks = it.backStacks.reversed(), fwdStacks = it.fwdStacks.reversed(), activePane = 1 - it.activePane) }
        reload()
    }

    private fun activeDirectory(s: BrowserState = _s.value): File = File(if (s.dualPane && s.activePane == 1) s.secondaryDir else s.dir)

    fun navigateUpActive(): Boolean {
        val s = _s.value
        if (s.selected.isNotEmpty()) { clearSelection(); return true }
        val current = activeDirectory(s)
        val root = File(s.root)
        if (current.absolutePath == root.absolutePath) {
            if (s.dualPane) {
                val other = if (s.activePane == 0) File(s.secondaryDir) else File(s.dir)
                if (other.absolutePath != root.absolutePath) { setActivePane(1 - s.activePane); return true }
            }
            return false
        }
        val parent = current.parentFile ?: return false
        if (s.dualPane && s.activePane == 1) openSecondary(parent.absolutePath) else open(parent.absolutePath)
        return true
    }

    /** Go to the parent folder (also leaves the browser root, unlike back). */
    fun goUp() {
        val cur = activeDirectory(); val parent = cur.parentFile
        if (parent == null) { notify("Already at the top"); return }
        if (_s.value.root.isNotEmpty() && cur.absolutePath == _s.value.root) _s.update { it.copy(root = "/") }
        openActive(parent.absolutePath)
    }

    /** @return false when already at root (caller should leave the browser). */
    fun up(): Boolean {
        val s = _s.value
        if (s.selected.isNotEmpty()) { clearSelection(); return true }
        if (s.searching) { _s.update { it.copy(searching = false, query = "") }; reload(); return true }
        return navigateUpActive()
    }

    private var reloadJob: Job? = null

    fun reload() {
        reloadJob?.cancel()
        reloadJob = viewModelScope.launch {
            // Debounce typing in search so we don't walk the disk on every keystroke.
            if (_s.value.searching && _s.value.query.isNotBlank()) delay(120)
            val snapshot = _s.value
            _s.update { it.copy(loading = true) }
            val (main, secondary) = coroutineScope {
                val mainTask = async(Dispatchers.IO) {
                    if (snapshot.searching && snapshot.query.isNotBlank() && snapshot.grep) FileOps.grep(File(snapshot.dir), snapshot.query, snapshot.showHidden)
                    else if (snapshot.searching && snapshot.query.isNotBlank()) repo.search(File(snapshot.dir), snapshot.query, snapshot.showHidden, SettingsStore.searchMode, SettingsStore.searchAgeMs)
                    else repo.list(File(snapshot.dir), snapshot.showHidden, snapshot.sort)
                }
                val secondaryTask = if (snapshot.dualPane) async(Dispatchers.IO) {
                    repo.list(File(snapshot.secondaryDir), snapshot.showHidden, snapshot.sort)
                } else null
                mainTask.await() to (secondaryTask?.await() ?: snapshot.secondaryItems)
            }
            if (main.isEmpty() && !snapshot.searching) {
                val d = File(snapshot.dir)
                if (d.isDirectory && d.listFiles() == null) _s.update { it.copy(message = "Permission denied: this folder can't be read") }
            }
            _s.update { current ->
                if (current.dir != snapshot.dir || current.secondaryDir != snapshot.secondaryDir ||
                    current.query != snapshot.query || current.searching != snapshot.searching ||
                    current.showHidden != snapshot.showHidden || current.grep != snapshot.grep || current.sort != snapshot.sort || current.dualPane != snapshot.dualPane) current
                else current.copy(items = main, secondaryItems = secondary, loading = false)
            }
        }
    }

    /** Jump straight to any absolute path. If it lies outside the current root the root becomes "/" so back-navigation still works. */
    fun jump(raw: String) {
        val text = raw.trim()
        if (text.isEmpty()) return
        val f = File(text)
        if (!f.exists()) { notify("Path not found"); return }
        if (!f.isDirectory) { notify("Not a folder"); return }
        val target = f.absolutePath
        val r = _s.value.root.trimEnd('/')
        if (r.isNotEmpty() && target != r && !target.startsWith("$r/")) _s.update { it.copy(root = "/") }
        if (!f.canRead()) notify("Folder may not be readable")
        openActive(target)
    }

    fun moveToPrivate(ctx: Context) {
        if (!com.kayx.manager.data.storage.PrivateSpace.hasPin(ctx)) { notify("Open Private space on Home and create a PIN first"); return }
        val files = _s.value.selected.map(::File)
        val dst = com.kayx.manager.data.storage.PrivateSpace.dir(ctx)
        run({ FileOps.transfer(files, dst, true, Conflict.KEEP_BOTH).map { } }, "Moved ${files.size} to Private space")
        com.kayx.manager.data.storage.StorageScanner.invalidate()
    }

    fun toggleSearch() { _s.update { it.copy(searching = !it.searching, query = "") }; reload() }
    fun setQuery(q: String) { _s.update { it.copy(query = q) }; reload() }
    fun toggleHidden() { _s.update { it.copy(showHidden = !it.showHidden) }; reload() }
    fun setSort(s: SortBy) { _s.update { it.copy(sort = s) }; reload() }
    private fun updateActiveSelection(transform: (Set<String>) -> Set<String>) = _s.update { st ->
        if (st.dualPane && st.activePane == 1) st.copy(secondarySelected = transform(st.secondarySelected))
        else st.copy(primarySelected = transform(st.primarySelected))
    }
    fun toggleSelect(path: String) = updateActiveSelection { if (path in it) it - path else it + path }
    fun selectAll() = _s.update { st ->
        val paths = (if (st.dualPane && st.activePane == 1) st.secondaryItems else st.items).map { it.path }.toSet()
        if (st.dualPane && st.activePane == 1) st.copy(secondarySelected = paths) else st.copy(primarySelected = paths)
    }
    fun clearSelection() = updateActiveSelection { emptySet() }
    private fun clearPaneSelection(pane: Int) = _s.update { st ->
        if (pane == 1) st.copy(secondarySelected = emptySet()) else st.copy(primarySelected = emptySet())
    }
    fun notify(msg: String) = _s.update { it.copy(message = msg) }
    fun consumeMessage() = _s.update { it.copy(message = null) }
    fun copySelected(cut: Boolean) = _s.update { st ->
        val picked = st.selected.toList()
        if (st.dualPane && st.activePane == 1) st.copy(clipboard = picked, cut = cut, secondarySelected = emptySet(), message = if (cut) "Cut ${picked.size}" else "Copied ${picked.size}")
        else st.copy(clipboard = picked, cut = cut, primarySelected = emptySet(), message = if (cut) "Cut ${picked.size}" else "Copied ${picked.size}")
    }
    fun clearClipboard() = _s.update { it.copy(clipboard = emptyList()) }

    private fun run(op: suspend () -> Result<Unit>, ok: String? = null) = viewModelScope.launch {
        val initial = _s.value
        val sourcePane = if (initial.dualPane && initial.activePane == 1) 1 else 0
        val r = withContext(Dispatchers.IO) { op() }
        repo.invalidateSearchCache()
        clearPaneSelection(sourcePane)
        _s.update { it.copy(message = r.exceptionOrNull()?.message ?: ok) }
        reload()
    }

    /** Paste the clipboard into the active pane's folder ("single-window" copy/move). */
    fun paste(policy: Conflict? = null) {
        val s = _s.value
        val pending = s.pending
        if (policy != null && pending != null) {
            startTransfer(pending.files.map(::File), File(pending.dst), pending.cut, policy, pending.sourcePane, pending.fromClipboard)
            return
        }
        startTransfer(s.clipboard.map(::File), activeDirectory(s), s.cut, policy, null, true)
    }

    /**
     * "Copy ->" / "Move ->": send the active pane's selection straight into the OTHER pane's folder
     * (the confirm dialog shows that folder). No clipboard and no separate paste step.
     */
    fun transferSelectedToOther(cut: Boolean, policy: Conflict? = null) {
        val s = _s.value
        if (!s.dualPane) { notify("Turn on dual pane first"); return }
        startTransfer(s.selected.map(::File), File(s.otherDir), cut, policy, s.activePane, false)
    }

    private fun startTransfer(files: List<File>, dst: File, cut: Boolean, policy: Conflict?, sourcePane: Int?, fromClipboard: Boolean) {
        if (files.isEmpty()) { notify("Nothing to ${if (cut) "move" else "copy"}"); return }
        if (policy == null) {
            val c = FileOps.conflicts(files, dst)
            if (c.isNotEmpty()) {
                _s.update { it.copy(conflicts = c, pending = PendingTransfer(files.map { f -> f.absolutePath }, dst.absolutePath, cut, sourcePane, fromClipboard)) }
                return
            }
        }
        val st = _s.value
        val destinationPane = if (st.dualPane && st.activePane == 1) 1 else 0
        _s.update { it.copy(conflicts = emptyList(), pending = null, recent = emptySet()) }
        viewModelScope.launch {
            _s.update { it.copy(transferProgress = TransferProgress(0, files.size, "Preparing", cut)) }
            val before = withContext(Dispatchers.IO) { dst.list()?.toSet().orEmpty() }
            val result = withContext(Dispatchers.IO) {
                FileOps.transfer(files, dst, cut, policy ?: Conflict.KEEP_BOTH) { completed, total, name ->
                    _s.update { it.copy(transferProgress = TransferProgress(completed, total, name, cut)) }
                }.map { }
            }
            repo.invalidateSearchCache()
            // Everything new in the destination is highlighted so the user can see what just arrived.
            val fresh = withContext(Dispatchers.IO) {
                val after = dst.list()?.toSet().orEmpty()
                ((after - before) + files.map { it.name }.filter { n -> File(dst, n).exists() }).map { n -> File(dst, n).absolutePath }.toSet()
            }
            clearPaneSelection(sourcePane ?: destinationPane)
            _s.update {
                it.copy(
                    transferProgress = null,
                    recent = if (result.isSuccess) fresh else emptySet(),
                    message = result.exceptionOrNull()?.message ?: (if (cut) "Moved ${files.size}" else "Copied ${files.size}")
                )
            }
            if (fromClipboard && cut && result.isSuccess) clearClipboard()
            reload()
        }
    }
    fun dismissConflicts() = _s.update { it.copy(conflicts = emptyList(), pending = null) }
    fun newFolder(n: String) = run({ repo.createFolder(activeDirectory(), n) })
    fun newFile(n: String) = run({ repo.createFile(activeDirectory(), n) })
    fun rename(path: String, n: String) = run({ repo.rename(File(path), n) })
    fun zipSelected(name: String) {
        val f = _s.value.selected.map(::File)
        val n = name.trim().replace('/', '_').ifEmpty { "archive" }.let { if (it.endsWith(".zip", true)) it else "$it.zip" }
        val out = File(activeDirectory(), n)
        run({ archive.create(f, out) }, "Created $n")
    }
    fun deleteSelected() {
        val f = _s.value.selected.map(::File)
        if (SettingsStore.useRecycleBin) run({ withContext(Dispatchers.IO) { RecycleBin.trash(f) } }, "Moved ${f.size} to recycle bin")
        else run({ repo.delete(f) }, "Deleted ${f.size}")
    }

    // ---- MT-Manager-style extras ----
    fun toggleGrep() { _s.update { it.copy(grep = !it.grep) }; reload() }
    fun invertSelection() = _s.update { st ->
        val all = (if (st.dualPane && st.activePane == 1) st.secondaryItems else st.items).map { it.path }.toSet()
        if (st.dualPane && st.activePane == 1) st.copy(secondarySelected = all - st.secondarySelected) else st.copy(primarySelected = all - st.primarySelected)
    }
    fun selectPattern(p: String) = _s.update { st ->
        val rx = FileOps.globToRegex(p.trim())
        val list = if (st.dualPane && st.activePane == 1) st.secondaryItems else st.items
        if (st.dualPane && st.activePane == 1) st.copy(secondarySelected = list.filter { rx.matches(it.name) }.map { it.path }.toSet()) else st.copy(primarySelected = list.filter { rx.matches(it.name) }.map { it.path }.toSet())
    }
    fun duplicateSelected() { val f = _s.value.selected.map(::File); run({ FileOps.duplicate(f) }, "Duplicated ${f.size}") }
    fun batchRename(find: String, replace: String, regex: Boolean, start: Int) {
        val f = _s.value.selected.map(::File).sortedBy { it.name.lowercase() }
        run({ FileOps.batchRename(f, find, replace, regex, start) }, "Renamed ${f.size}")
    }
    fun symlink(target: String, name: String) = run({ runCatching { FileOps.symlink(File(target), File(activeDirectory(), name)) } }, "Symlink created")

    fun extractHere(path: String) {
        viewModelScope.launch {
            notify("Extracting…")
            val r = withContext(Dispatchers.IO) { MultiExtract.extract(File(path)) }
            repo.invalidateSearchCache()
            _s.update { st -> st.copy(message = r.fold({ p -> "Extracted ${p.second} file(s) → ${p.first.name}" }, { e -> e.message ?: "Extraction failed" })) }
            reload()
        }
    }
    fun alignZip(path: String) {
        viewModelScope.launch {
            val r = withContext(Dispatchers.IO) { ArchiveEdit.rewrite(File(path)) }
            repo.invalidateSearchCache()
            _s.update { st -> st.copy(message = r.fold({ "Aligned" }, { e -> e.message ?: "Align failed" })) }
            reload()
        }
    }
    fun signApk(ctx: Context, path: String) {
        viewModelScope.launch {
            notify("Signing…")
            val f = File(path)
            val out = FileOps.uniqueName(f.parentFile ?: f, f.nameWithoutExtension + "_signed.apk")
            val r = withContext(Dispatchers.IO) { ApkSignRepo.sign(ctx.applicationContext, f, out) }
            _s.update { st -> st.copy(message = r.fold({ "Signed → ${out.name}" }, { e -> "Sign failed: ${e.message}" })) }
            reload()
        }
    }
}
