package com.kayx.manager.feature.filebrowser

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.kayx.manager.data.archive.ArchiveRepository
import android.content.Context
import com.kayx.manager.data.apk.ApkSignRepo
import com.kayx.manager.data.archive.ArchiveEdit
import com.kayx.manager.data.archive.MultiExtract
import com.kayx.manager.data.filesystem.Conflict
import com.kayx.manager.data.filesystem.RecycleBin
import com.kayx.manager.data.filesystem.FileOps
import com.kayx.manager.data.filesystem.FileRepository
import com.kayx.manager.data.settings.SettingsStore
import com.kayx.manager.domain.model.FileItem
import com.kayx.manager.domain.model.SortBy
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

data class BrowserState(
    val root: String = "",
    val dir: String = "",
    val items: List<FileItem> = emptyList(),
    val selected: Set<String> = emptySet(),
    val clipboard: List<String> = emptyList(),
    val cut: Boolean = false,
    val query: String = "",
    val searching: Boolean = false,
    val showHidden: Boolean = false,
    val sort: SortBy = SortBy.NAME,
    val loading: Boolean = false,
    val message: String? = null,
    val secondaryDir: String = "",
    val secondaryItems: List<FileItem> = emptyList(),
    val dualPane: Boolean = false,
    val activePane: Int = 0,
    val grep: Boolean = false,
    val conflicts: List<String> = emptyList()
)

class FileBrowserViewModel(private val repo: FileRepository = FileRepository(), private val archive: ArchiveRepository = ArchiveRepository()) : ViewModel() {
    private val _s = MutableStateFlow(BrowserState(showHidden = SettingsStore.showHidden, sort = SettingsStore.defaultSort, dualPane = SettingsStore.dualPane))
    private var applied = Triple(SettingsStore.showHidden, SettingsStore.defaultSort, SettingsStore.dualPane)
    val state: StateFlow<BrowserState> = _s

    /** Start a browsing session at [path] (this becomes the root). */
    fun start(path: String) {
        if (_s.value.root == path) { reload(); return }
        _s.update { it.copy(root = path, secondaryDir = path, secondaryItems = emptyList(), activePane = 0) }; open(path)
    }

    fun open(path: String) {
        _s.update { it.copy(dir = path, selected = emptySet(), query = "", searching = false, activePane = 0) }; reload()
    }

    /** Re-apply browser defaults only when they were changed in Settings (keeps in-browser toggles otherwise). */
    fun syncDefaults() {
        val now = Triple(SettingsStore.showHidden, SettingsStore.defaultSort, SettingsStore.dualPane)
        if (now == applied) return
        applied = now
        _s.update { c -> c.copy(showHidden = now.first, sort = now.second, dualPane = now.third,
            secondaryDir = c.secondaryDir.ifBlank { c.root.ifBlank { c.dir } }) }
        reload()
    }

    fun toggleDualPane() {
        _s.update { current ->
            val enabled = !current.dualPane
            current.copy(dualPane = enabled, secondaryDir = current.secondaryDir.ifBlank { current.root.ifBlank { current.dir } })
        }
        reload()
    }

    fun setActivePane(pane: Int) { _s.update { it.copy(activePane = pane.coerceIn(0, 1)) } }

    fun openSecondary(path: String) {
        _s.update { it.copy(secondaryDir = path, activePane = 1, selected = emptySet()) }
        reload()
    }

    fun openActive(path: String) {
        if (_s.value.dualPane && _s.value.activePane == 1) openSecondary(path) else open(path)
    }

    fun swapPanes() {
        _s.update { it.copy(dir = it.secondaryDir, secondaryDir = it.dir, activePane = 1 - it.activePane, selected = emptySet()) }
        reload()
    }

    private fun activeDirectory(s: BrowserState = _s.value): File = File(if (s.dualPane && s.activePane == 1) s.secondaryDir else s.dir)

    fun navigateUpActive(): Boolean {
        val s = _s.value
        if (s.selected.isNotEmpty()) { clearSelection(); return true }
        val current = activeDirectory(s)
        val root = File(s.root)
        if (current.absolutePath == root.absolutePath) {
            if (s.dualPane) {
                val other = if (s.activePane == 0) File(s.secondaryDir) else File(s.dir)
                if (other.absolutePath != root.absolutePath) { setActivePane(1 - s.activePane); return true }
            }
            return false
        }
        val parent = current.parentFile ?: return false
        if (s.dualPane && s.activePane == 1) openSecondary(parent.absolutePath) else open(parent.absolutePath)
        return true
    }

    /** @return false when already at root (caller should leave the browser). */
    fun up(): Boolean {
        val s = _s.value
        if (s.selected.isNotEmpty()) { _s.update { it.copy(selected = emptySet()) }; return true }
        if (s.searching) { _s.update { it.copy(searching = false, query = "") }; reload(); return true }
        return navigateUpActive()
    }

    fun reload() {
        viewModelScope.launch {
            val snapshot = _s.value
            _s.update { it.copy(loading = true) }
            val main = withContext(Dispatchers.IO) {
                if (snapshot.searching && snapshot.query.isNotBlank() && snapshot.grep) FileOps.grep(File(snapshot.dir), snapshot.query, snapshot.showHidden)
                else if (snapshot.searching && snapshot.query.isNotBlank()) repo.search(File(snapshot.dir), snapshot.query, snapshot.showHidden, SettingsStore.searchMode, SettingsStore.searchAgeMs)
                else repo.list(File(snapshot.dir), snapshot.showHidden, snapshot.sort)
            }
            val secondary = if (snapshot.dualPane) withContext(Dispatchers.IO) {
                repo.list(File(snapshot.secondaryDir), snapshot.showHidden, snapshot.sort)
            } else snapshot.secondaryItems
            _s.update { current ->
                if (current.dir != snapshot.dir || current.secondaryDir != snapshot.secondaryDir ||
                    current.query != snapshot.query || current.searching != snapshot.searching ||
                    current.showHidden != snapshot.showHidden || current.grep != snapshot.grep || current.sort != snapshot.sort || current.dualPane != snapshot.dualPane) current
                else current.copy(items = main, secondaryItems = secondary, loading = false)
            }
        }
    }

    fun toggleSearch() { _s.update { it.copy(searching = !it.searching, query = "") }; reload() }
    fun setQuery(q: String) { _s.update { it.copy(query = q) }; reload() }
    fun toggleHidden() { _s.update { it.copy(showHidden = !it.showHidden) }; reload() }
    fun setSort(s: SortBy) { _s.update { it.copy(sort = s) }; reload() }
    fun toggleSelect(path: String) = _s.update { it.copy(selected = if (path in it.selected) it.selected - path else it.selected + path) }
    fun selectAll() = _s.update { it.copy(selected = (if (it.dualPane && it.activePane == 1) it.secondaryItems else it.items).map { i -> i.path }.toSet()) }
    fun clearSelection() = _s.update { it.copy(selected = emptySet()) }
    fun notify(msg: String) = _s.update { it.copy(message = msg) }
    fun consumeMessage() = _s.update { it.copy(message = null) }
    fun copySelected(cut: Boolean) = _s.update { it.copy(clipboard = it.selected.toList(), cut = cut, selected = emptySet(), message = if (cut) "Cut ${it.selected.size}" else "Copied ${it.selected.size}") }
    fun clearClipboard() = _s.update { it.copy(clipboard = emptyList()) }

    private fun run(op: suspend () -> Result<Unit>, ok: String? = null) = viewModelScope.launch {
        val r = withContext(Dispatchers.IO) { op() }
        _s.update { it.copy(selected = emptySet(), message = r.exceptionOrNull()?.message ?: ok) }
        reload()
    }

    fun paste(policy: Conflict? = null) {
        val s = _s.value; val files = s.clipboard.map(::File); val dst = activeDirectory(s)
        if (policy == null) {
            val c = FileOps.conflicts(files, dst)
            if (c.isNotEmpty()) { _s.update { it.copy(conflicts = c) }; return }
        }
        _s.update { it.copy(conflicts = emptyList()) }
        val cut = s.cut
        run({ FileOps.transfer(files, dst, cut, policy ?: Conflict.KEEP_BOTH).map { } }, "Done")
        if (cut) clearClipboard()
    }
    fun dismissConflicts() = _s.update { it.copy(conflicts = emptyList()) }
    fun newFolder(n: String) = run({ repo.createFolder(activeDirectory(), n) })
    fun newFile(n: String) = run({ repo.createFile(activeDirectory(), n) })
    fun rename(path: String, n: String) = run({ repo.rename(File(path), n) })
    fun zipSelected(name: String) {
        val f = _s.value.selected.map(::File)
        val n = name.trim().replace('/', '_').ifEmpty { "archive" }.let { if (it.endsWith(".zip", true)) it else "$it.zip" }
        val out = File(activeDirectory(), n)
        run({ archive.create(f, out) }, "Created $n")
    }
    fun deleteSelected() {
        val f = _s.value.selected.map(::File)
        if (SettingsStore.useRecycleBin) run({ withContext(Dispatchers.IO) { RecycleBin.trash(f) } }, "Moved ${f.size} to recycle bin")
        else run({ repo.delete(f) }, "Deleted ${f.size}")
    }

    // ---- MT-Manager-style extras ----
    fun toggleGrep() { _s.update { it.copy(grep = !it.grep) }; reload() }
    fun invertSelection() = _s.update { st ->
        val all = (if (st.dualPane && st.activePane == 1) st.secondaryItems else st.items).map { it.path }.toSet()
        st.copy(selected = all - st.selected)
    }
    fun selectPattern(p: String) = _s.update { st ->
        val rx = FileOps.globToRegex(p.trim())
        val list = if (st.dualPane && st.activePane == 1) st.secondaryItems else st.items
        st.copy(selected = list.filter { rx.matches(it.name) }.map { it.path }.toSet())
    }
    fun duplicateSelected() { val f = _s.value.selected.map(::File); run({ FileOps.duplicate(f) }, "Duplicated ${f.size}") }
    fun batchRename(find: String, replace: String, regex: Boolean, start: Int) {
        val f = _s.value.selected.map(::File).sortedBy { it.name.lowercase() }
        run({ FileOps.batchRename(f, find, replace, regex, start) }, "Renamed ${f.size}")
    }
    fun symlink(target: String, name: String) = run({ runCatching { FileOps.symlink(File(target), File(activeDirectory(), name)) } }, "Symlink created")

    fun extractHere(path: String) {
        viewModelScope.launch {
            notify("Extracting…")
            val r = withContext(Dispatchers.IO) { MultiExtract.extract(File(path)) }
            _s.update { st -> st.copy(message = r.fold({ p -> "Extracted ${p.second} file(s) → ${p.first.name}" }, { e -> e.message ?: "Extraction failed" })) }
            reload()
        }
    }
    fun alignZip(path: String) {
        viewModelScope.launch {
            val r = withContext(Dispatchers.IO) { ArchiveEdit.rewrite(File(path)) }
            _s.update { st -> st.copy(message = r.fold({ "Aligned" }, { e -> e.message ?: "Align failed" })) }
            reload()
        }
    }
    fun signApk(ctx: Context, path: String) {
        viewModelScope.launch {
            notify("Signing…")
            val f = File(path)
            val out = FileOps.uniqueName(f.parentFile ?: f, f.nameWithoutExtension + "_signed.apk")
            val r = withContext(Dispatchers.IO) { ApkSignRepo.sign(ctx.applicationContext, f, out) }
            _s.update { st -> st.copy(message = r.fold({ "Signed → ${out.name}" }, { e -> "Sign failed: ${e.message}" })) }
            reload()
        }
    }
}
