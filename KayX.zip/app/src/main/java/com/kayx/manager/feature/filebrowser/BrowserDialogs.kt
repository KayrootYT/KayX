package com.kayx.manager.feature.filebrowser

import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.kayx.manager.data.filesystem.Conflict
import com.kayx.manager.data.filesystem.FileOps
import com.kayx.manager.domain.model.FileItem
import com.kayx.manager.ui.theme.Accent
import com.kayx.manager.ui.theme.Fg
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.text.DateFormat
import java.util.Date

private fun size(b: Long): String {
    if (b < 1024) return "$b B"
    val u = arrayOf("KB", "MB", "GB", "TB"); var v = b / 1024.0; var i = 0
    while (v >= 1024 && i < u.lastIndex) { v /= 1024; i++ }
    return "%.1f %s".format(v, u[i])
}

/** Tappable path segments (MT-style). */
@Composable
internal fun BreadcrumbBar(path: String, onGo: (String) -> Unit) {
    val parts = path.split('/').filter { it.isNotEmpty() }
    val scroll = rememberScrollState()
    LaunchedEffect(path, scroll.maxValue) { scroll.scrollTo(scroll.maxValue) }
    Row(Modifier.horizontalScroll(scroll), verticalAlignment = Alignment.CenterVertically) {
        Text("/", Modifier.clickable { onGo("/") }.padding(horizontal = 3.dp), style = MaterialTheme.typography.bodySmall, color = Fg.copy(.6f))
        parts.forEachIndexed { i, p ->
            Text(p, Modifier.clickable { onGo("/" + parts.take(i + 1).joinToString("/")) }.padding(horizontal = 3.dp),
                maxLines = 1, style = MaterialTheme.typography.bodySmall, color = if (i == parts.lastIndex) Accent else Fg.copy(.6f))
            if (i < parts.lastIndex) Text("›", style = MaterialTheme.typography.bodySmall, color = Fg.copy(.4f))
        }
    }
}

@Composable
internal fun PropertiesDialog(f: FileItem, onClose: () -> Unit, onChanged: () -> Unit) {
    val file = remember(f.path) { File(f.path) }
    var info by remember { mutableStateOf<Pair<Long, Int>?>(null) }
    var mode by remember { mutableStateOf(FileOps.modeOf(file)) }
    var recursive by remember { mutableStateOf(false) }
    var msg by remember { mutableStateOf<String?>(null) }
    LaunchedEffect(f.path) { info = withContext(Dispatchers.IO) { FileOps.sizeAndCount(file) } }
    AlertDialog(onClose, title = { Text("Properties") }, text = {
        Column(verticalArrangement = Arrangement.spacedBy(5.dp)) {
            Text(f.name, style = MaterialTheme.typography.titleSmall)
            Text("Path: ${f.path}", style = MaterialTheme.typography.bodySmall)
            Text("Type: ${if (f.isDir) "Folder" else f.name.substringAfterLast('.', "File").uppercase()}")
            Text("Size: " + (info?.let { size(it.first) + if (f.isDir) "  (${it.second} items)" else "" } ?: "calculating…"))
            Text("Modified: ${DateFormat.getDateTimeInstance().format(Date(f.modified))}")
            val m = mode
            if (m != null) {
                Text("Permissions: ${FileOps.modeString(m)} (%04o)".format(m), color = Accent)
                listOf("Owner", "Group", "Others").forEachIndexed { row, label ->
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(label, Modifier.width(62.dp), style = MaterialTheme.typography.bodySmall)
                        listOf("R" to 4, "W" to 2, "X" to 1).forEach { (l, v) ->
                            val bit = v shl ((2 - row) * 3)
                            Checkbox((m and bit) != 0, { _ ->
                                val nm = m xor bit
                                runCatching { FileOps.chmod(file, nm, recursive) }
                                    .onSuccess { mode = FileOps.modeOf(file); onChanged() }
                                    .onFailure { msg = it.message ?: "chmod failed" }
                            })
                            Text(l, style = MaterialTheme.typography.bodySmall)
                            Spacer(Modifier.width(8.dp))
                        }
                    }
                }
                if (f.isDir) Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(recursive, { recursive = it }); Text("Apply recursively", style = MaterialTheme.typography.bodySmall)
                }
            }
            msg?.let { Text(it, color = Color(0xFFFF6B6B), style = MaterialTheme.typography.bodySmall) }
        }
    }, confirmButton = { TextButton(onClose) { Text("Close") } })
}

@Composable
internal fun BatchRenameDialog(count: Int, onDismiss: () -> Unit, onOk: (String, String, Boolean, Int) -> Unit) {
    var find by remember { mutableStateOf("") }
    var rep by remember { mutableStateOf("") }
    var regex by remember { mutableStateOf(false) }
    var start by remember { mutableStateOf("1") }
    AlertDialog(onDismiss, title = { Text("Batch rename ($count)") }, text = {
        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
            OutlinedTextField(find, { find = it }, singleLine = true, label = { Text("Find (empty = use template)") })
            OutlinedTextField(rep, { rep = it }, singleLine = true, label = { Text("Replace / template") })
            Text("Tokens: {n} counter, {name} base name, {ext} extension", style = MaterialTheme.typography.labelSmall, color = Fg.copy(.6f))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Checkbox(regex, { regex = it }); Text("Regex")
                Spacer(Modifier.width(12.dp))
                OutlinedTextField(start, { start = it.filter(Char::isDigit) }, Modifier.width(100.dp), singleLine = true, label = { Text("Start #") })
            }
        }
    }, confirmButton = { TextButton({ onOk(find, rep, regex, start.toIntOrNull() ?: 1) }) { Text("Rename") } },
        dismissButton = { TextButton(onDismiss) { Text("Cancel") } })
}

@Composable
internal fun ConflictDialog(names: List<String>, onPick: (Conflict) -> Unit, onCancel: () -> Unit) {
    AlertDialog(onCancel, title = { Text("${names.size} item(s) already exist") }, text = {
        Column {
            Text(names.take(5).joinToString("\n") + if (names.size > 5) "\n…" else "", style = MaterialTheme.typography.bodySmall)
            TextButton({ onPick(Conflict.REPLACE) }, Modifier.fillMaxWidth()) { Text("Replace", color = Color(0xFFFF6B6B)) }
            TextButton({ onPick(Conflict.KEEP_BOTH) }, Modifier.fillMaxWidth()) { Text("Keep both (rename)") }
            TextButton({ onPick(Conflict.SKIP) }, Modifier.fillMaxWidth()) { Text("Skip existing") }
        }
    }, confirmButton = {}, dismissButton = { TextButton(onCancel) { Text("Cancel") } })
}
