package com.kayx.manager

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.SystemBarStyle
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import com.kayx.manager.domain.model.Tool
import com.kayx.manager.feature.filebrowser.FileBrowserScreen
import com.kayx.manager.feature.tools.*
import com.kayx.manager.feature.home.HomeScreen
import com.kayx.manager.feature.settings.SettingsScreen
import com.kayx.manager.ui.theme.isKayXDark
import com.kayx.manager.ui.glass.GlassCard
import com.kayx.manager.ui.glass.glassBackground
import com.kayx.manager.ui.theme.KayXTheme

class MainActivity : ComponentActivity() {
    private val granted = mutableStateOf(false)
    private val legacyPerm = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { granted.value = hasAccess() }

    private fun hasAccess() = if (Build.VERSION.SDK_INT >= 30) Environment.isExternalStorageManager()
    else ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED

    private fun requestAccess() {
        if (Build.VERSION.SDK_INT >= 30)
            startActivity(Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, Uri.parse("package:$packageName")))
        else legacyPerm.launch(arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE))
    }

    override fun onResume() { super.onResume(); granted.value = hasAccess() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            // Keep status/navigation bar icons readable in Light vs Dark/AMOLED.
            val dark = isKayXDark()
            DisposableEffect(dark) {
                val style = SystemBarStyle.auto(android.graphics.Color.TRANSPARENT, android.graphics.Color.TRANSPARENT) { dark }
                enableEdgeToEdge(statusBarStyle = style, navigationBarStyle = style)
                onDispose { }
            }
            KayXTheme {
                var showSettings by remember { mutableStateOf(false) }
                var path by remember { mutableStateOf<String?>(null) }
                var stack by remember { mutableStateOf(listOf<Pair<String, Tool>>()) }
                val push = { f: String, k: Tool -> stack = stack + (f to k) }
                if (!granted.value) Box(Modifier.fillMaxSize().glassBackground().padding(24.dp), Alignment.Center) {
                    GlassCard(Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(22.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                            Text("Storage access needed", style = MaterialTheme.typography.titleLarge)
                            Text("KayX works fully offline. It only needs file access to browse and manage your files.")
                            Button(::requestAccess) { Text("Grant access") }
                        }
                    }
                } else {
                    val p = path
                    val t = stack.lastOrNull()
                    if (t != null) {
                        val close = { stack = stack.dropLast(1) }
                        when (t.second) {
                            Tool.TEXT -> TextEditorPro(t.first, close)
                            Tool.HEX -> HexViewerScreen(t.first, close)
                            Tool.IMAGE -> ImageViewerScreen(t.first, close)
                            Tool.ZIP -> ZipScreen(t.first, close, push)
                            Tool.CHECKSUM -> ChecksumScreen(t.first, close)
                            Tool.APK -> ApkInspectorScreen(t.first, close) { push(t.first, Tool.DEX) }
                            Tool.DEX -> DexInspectorScreen(t.first, close)
                            Tool.COMPARE -> FileComparisonScreen(t.first, t.first, close)
                            Tool.HTML -> HtmlPreviewScreen(t.first, close)
                            Tool.ZIPTEXT -> ZipEntryEditorScreen(t.first, close)
                            Tool.AXML -> AxmlViewerScreen(t.first, close)
                            Tool.APPS -> com.kayx.manager.feature.apps.AppManagerScreen(close) { push(it, Tool.APK) }
                        }
                    } else if (showSettings) {
                        SettingsScreen(storageGranted = granted.value, onManageStorage = ::requestAccess, onBack = { showSettings = false })
                    } else if (p != null) {
                        FileBrowserScreen(p, onExit = { path = null }, onOpenFile = { f, k -> push(f, k) }, onSettings = { showSettings = true })
                    } else HomeScreen(onSettings = { showSettings = true }, onApps = { push("", Tool.APPS) }) { path = it }
                }
            }
        }
    }
}
