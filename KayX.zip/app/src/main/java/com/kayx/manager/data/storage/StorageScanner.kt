package com.kayx.manager.data.storage

import android.content.Context
import android.media.MediaScannerConnection
import android.os.Environment
import android.os.StatFs
import android.provider.MediaStore
import java.io.File
import java.security.MessageDigest
import java.util.Locale

enum class Category(val label: String, val exts: Set<String>) {
    IMAGES("Images", setOf("jpg", "jpeg", "png", "gif", "webp", "bmp", "heic", "heif")),
    VIDEOS("Videos", setOf("mp4", "mkv", "avi", "mov", "webm", "3gp", "flv", "m4v")),
    AUDIO("Audio", setOf("mp3", "m4a", "wav", "flac", "ogg", "aac", "opus", "amr")),
    DOCUMENTS("Documents", setOf("pdf", "doc", "docx", "xls", "xlsx", "ppt", "pptx", "txt", "odt", "ods", "odp", "rtf", "csv", "epub")),
    APKS("APKs", setOf("apk", "apks", "xapk", "apkm")),
    ARCHIVES("Archives", setOf("zip", "rar", "7z", "tar", "gz", "bz2", "xz", "jar"));

    companion object {
        fun of(fileName: String): Category? {
            val ext = fileName.substringAfterLast('.', "").lowercase(Locale.ROOT)
            return values().firstOrNull { ext in it.exts }
        }
    }
}

data class ScanFile(val path: String, val size: Long, val modified: Long, val category: Category?) {
    val name: String get() = path.substringAfterLast('/')
}

fun formatBytes(b: Long): String {
    if (b < 1024) return "$b B"
    val units = arrayOf("KB", "MB", "GB", "TB")
    var v = b.toDouble(); var i = -1
    while (v >= 1024 && i < units.lastIndex) { v /= 1024; i++ }
    return String.format(Locale.US, if (v >= 100) "%.0f %s" else "%.1f %s", v, units[i])
}

class CleanupAnalysis(
    val large: List<ScanFile>, val duplicates: List<ScanFile>, val oldVideos: List<ScanFile>,
    val whatsappJunk: List<ScanFile>, private val byCategory: Map<Category, List<ScanFile>>
) {
    val duplicateBytes: Long get() = duplicates.sumOf { it.size }
    val oldVideoBytes: Long get() = oldVideos.sumOf { it.size }
    val whatsappBytes: Long get() = whatsappJunk.sumOf { it.size }
    fun of(c: Category): List<ScanFile> = byCategory[c].orEmpty()
}

object QuickAccess {
    class Target(val name: String, val dirs: List<File>)
    private val root get() = StorageScanner.externalRoot()
    val targets: List<Target> by lazy {
        fun t(n: String, vararg rel: String) = Target(n, rel.map { File(root, it) })
        listOf(
            t("WhatsApp", "Android/media/com.whatsapp/WhatsApp", "WhatsApp"),
            t("Telegram", "Telegram", "Android/media/org.telegram.messenger/Telegram"),
            t("Screenshots", "Pictures/Screenshots", "DCIM/Screenshots"),
            t("Downloads", Environment.DIRECTORY_DOWNLOADS),
            t("Recorder", "Recordings", "Music/Recordings", "Sounds", "Recorder"),
            t("Bluetooth", "Bluetooth", "Download/Bluetooth")
        )
    }
    fun firstExisting(t: Target): File? = t.dirs.firstOrNull { it.isDirectory }
}

object MediaCounts {
    fun category(ctx: Context, c: Category): Int? = runCatching {
        val sel = c.exts.joinToString(" OR ") { "${MediaStore.Files.FileColumns.DATA} LIKE ?" }
        ctx.contentResolver.query(MediaStore.Files.getContentUri("external"), arrayOf(MediaStore.Files.FileColumns._ID),
            sel, c.exts.map { "%.$it" }.toTypedArray(), null)?.use { it.count }
    }.getOrNull()

    fun folders(ctx: Context, dirs: List<File>): Int = dirs.filter { it.isDirectory }.sumOf { d ->
        runCatching { d.walkTopDown().maxDepth(6).count { it.isFile } }.getOrDefault(0)
    }
}

object StorageScanner {
    private const val LARGE_BYTES = 100L * 1024 * 1024
    private const val OLD_VIDEO_MS = 180L * 24 * 3600 * 1000
    private val lock = Any()
    @Volatile private var files: List<File>? = null
    @Volatile private var analysis: CleanupAnalysis? = null

    fun externalRoot(): File = Environment.getExternalStorageDirectory()

    fun invalidate() { synchronized(lock) { files = null; analysis = null } }

    fun cachedAnalysis(): CleanupAnalysis? = analysis

    private fun allFiles(): List<File> = files ?: synchronized(lock) {
        files ?: externalRoot().walkTopDown().maxDepth(14)
            .onEnter { d -> !(d.parentFile == externalRoot() && d.name == "Android") && !d.name.startsWith(".thumb") }
            .filter { it.isFile }.toList().also { files = it }
    }

    private fun toScan(f: File) = ScanFile(f.absolutePath, f.length(), f.lastModified(), Category.of(f.name))

    /** All files that belong to a known category. */
    fun scan(): List<ScanFile> = allFiles().map(::toScan).filter { it.category != null }

    fun analyze(): CleanupAnalysis {
        analysis?.let { return it }
        val all = allFiles()
        val scanned = all.map(::toScan)
        val cats = scanned.filter { it.category != null }.groupBy { it.category!! }
        val large = scanned.filter { it.size >= LARGE_BYTES }.sortedByDescending { it.size }
        val now = System.currentTimeMillis()
        val old = cats[Category.VIDEOS].orEmpty().filter { now - it.modified > OLD_VIDEO_MS }.sortedByDescending { it.size }
        val junk = scanned.filter { s ->
            val p = s.path
            (p.contains("/WhatsApp/") || p.contains("/com.whatsapp/")) && (p.contains("/.Statuses/") || p.contains("/Sent/") || p.contains("/Cache/"))
        }
        val dupes = findDuplicates(scanned)
        return CleanupAnalysis(large, dupes, old, junk, cats).also { analysis = it }
    }

    private fun findDuplicates(all: List<ScanFile>): List<ScanFile> {
        val out = ArrayList<ScanFile>()
        all.filter { it.size >= 10 * 1024 }.groupBy { it.size }.values.filter { it.size > 1 }.forEach { group ->
            val byHash = HashMap<String, MutableList<ScanFile>>()
            for (s in group) hash(File(s.path))?.let { byHash.getOrPut(it) { ArrayList() }.add(s) }
            byHash.values.filter { it.size > 1 }.forEach { same ->
                // keep the oldest copy as the original
                out += same.sortedBy { it.modified }.drop(1)
            }
        }
        return out.sortedByDescending { it.size }
    }

    private fun hash(f: File): String? = runCatching {
        val md = MessageDigest.getInstance("MD5")
        f.inputStream().buffered().use { ins ->
            val buf = ByteArray(1 shl 16); var n: Int
            while (ins.read(buf).also { n = it } > 0) md.update(buf, 0, n)
        }
        md.digest().joinToString("") { "%02x".format(it) }
    }.getOrNull()

    /** Total and available bytes of shared storage, or null if unreadable. */
    fun deviceStorage(): Pair<Long, Long>? = runCatching {
        val st = StatFs(externalRoot().path)
        st.totalBytes to st.availableBytes
    }.getOrNull()

    /** Permanently deletes [list]. Returns (deleted count, freed bytes). */
    fun delete(ctx: Context, list: List<ScanFile>): Pair<Int, Long> {
        var n = 0; var freed = 0L
        val removed = ArrayList<String>()
        for (s in list) {
            val f = File(s.path)
            val size = f.length()
            if (f.isFile && f.delete()) { n++; freed += size; removed += s.path }
        }
        if (removed.isNotEmpty()) MediaScannerConnection.scanFile(ctx, removed.toTypedArray(), null, null)
        invalidate()
        return n to freed
    }
}
