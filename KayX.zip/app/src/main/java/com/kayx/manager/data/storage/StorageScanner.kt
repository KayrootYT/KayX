package com.kayx.manager.data.storage

import android.content.Context
import android.media.MediaScannerConnection
import android.os.Environment
import android.os.StatFs
import java.io.File
import java.security.MessageDigest

fun formatBytes(b: Long): String {
    if (b < 1024) return "$b B"
    val u = arrayOf("KB", "MB", "GB", "TB"); var v = b / 1024.0; var i = 0
    while (v >= 1024 && i < u.lastIndex) { v /= 1024; i++ }
    return if (i == 0) "%.0f %s".format(v, u[i]) else "%.2f %s".format(v, u[i])
}

enum class Category(val label: String, val exts: Set<String>) {
    IMAGES("Images", setOf("jpg", "jpeg", "png", "gif", "webp", "bmp", "heic", "heif")),
    VIDEOS("Videos", setOf("mp4", "mkv", "avi", "mov", "3gp", "webm", "flv", "wmv", "m4v", "ts")),
    AUDIO("Audio", setOf("mp3", "wav", "aac", "m4a", "flac", "ogg", "oga", "opus", "amr", "wma", "mid", "midi")),
    DOCUMENTS("Documents", setOf("pdf", "doc", "docx", "xls", "xlsx", "ppt", "pptx", "txt", "csv", "rtf", "odt", "epub", "md", "json", "xml", "html", "htm", "log")),
    APKS("APKs", setOf("apk", "apks", "xapk", "apkm")),
    ARCHIVES("Archives", setOf("zip", "rar", "7z", "tar", "gz", "bz2", "xz", "tgz", "jar"));

    companion object {
        fun of(name: String): Category? {
            val e = name.substringAfterLast('.', "").lowercase()
            return values().firstOrNull { e in it.exts }
        }
    }
}

data class ScanFile(val path: String, val size: Long, val modified: Long, val category: Category?) {
    val name: String get() = path.substringAfterLast('/')
}

data class CleanupAnalysis(
    val files: List<ScanFile>,
    /** Duplicate copies that can be removed (one original per group is kept). */
    val duplicates: List<ScanFile>,
    val oldVideos: List<ScanFile>,
    val large: List<ScanFile>,
    val whatsappJunk: List<ScanFile>
) {
    val duplicateBytes get() = duplicates.sumOf { it.size }
    val oldVideoBytes get() = oldVideos.sumOf { it.size }
    val whatsappBytes get() = whatsappJunk.sumOf { it.size }
    fun of(cat: Category) = files.filter { it.category == cat }
}

/** Walks shared storage once and caches the result so Home, categories and cleanup stay cheap. */
object StorageScanner {
    const val LARGE_BYTES = 100L * 1024 * 1024
    const val OLD_VIDEO_MS = 180L * 24 * 3600 * 1000

    @Volatile private var cache: List<ScanFile>? = null
    @Volatile private var analysis: CleanupAnalysis? = null

    fun externalRoot(): File = Environment.getExternalStorageDirectory()
    fun cached(): List<ScanFile>? = cache
    fun cachedAnalysis(): CleanupAnalysis? = analysis
    fun invalidate() { cache = null; analysis = null }

    fun scan(force: Boolean = false): List<ScanFile> {
        if (!force) cache?.let { return it }
        val out = ArrayList<ScanFile>(4096)
        val root = externalRoot()
        root.walkTopDown()
            .onEnter { d ->
                val n = d.name
                !(d != root && n.startsWith(".")) &&
                    !(d.parentFile?.name == "Android" && (n == "data" || n == "obb"))
            }
            .forEach { f ->
                if (f.isFile && !f.name.startsWith(".")) out += ScanFile(f.absolutePath, f.length(), f.lastModified(), Category.of(f.name))
            }
        cache = out
        return out
    }

    /** Files inside any of [dirs] (relative to shared storage or absolute). */
    fun resolve(rel: String): File = if (rel.startsWith("/")) File(rel) else File(externalRoot(), rel)

    fun countIn(files: List<ScanFile>, dirs: List<String>): Int {
        val prefixes = dirs.map { resolve(it).absolutePath.trimEnd('/') + "/" }
        return files.count { f -> prefixes.any { f.path.startsWith(it) } }
    }

    fun filesIn(files: List<ScanFile>, dirs: List<String>): List<ScanFile> {
        val prefixes = dirs.map { resolve(it).absolutePath.trimEnd('/') + "/" }
        return files.filter { f -> prefixes.any { f.path.startsWith(it) } }
    }

    private fun sha1(f: File): String? = runCatching {
        val md = MessageDigest.getInstance("SHA-1")
        f.inputStream().use { s ->
            val buf = ByteArray(64 * 1024)
            while (true) { val n = s.read(buf); if (n <= 0) break; md.update(buf, 0, n) }
        }
        md.digest().joinToString("") { "%02x".format(it) }
    }.getOrNull()

    private fun findDuplicates(files: List<ScanFile>): List<ScanFile> {
        val extras = ArrayList<ScanFile>()
        files.filter { it.size >= 1024 }.groupBy { it.size }.values.filter { it.size > 1 }.forEach { sameSize ->
            val byHash = HashMap<String, MutableList<ScanFile>>()
            sameSize.forEach { sf -> sha1(File(sf.path))?.let { byHash.getOrPut(it) { ArrayList() } += sf } }
            byHash.values.filter { it.size > 1 }.forEach { g ->
                // Keep the oldest copy (the original); the rest are duplicates.
                val sorted = g.sortedWith(compareBy({ it.modified }, { it.path.length }))
                extras += sorted.drop(1)
            }
        }
        return extras
    }

    private val whatsappJunkDirs = listOf(".Statuses", ".trash", ".Shared", ".Thumbs", ".links")
    private val whatsappRoots = listOf("Android/media/com.whatsapp/WhatsApp/Media", "WhatsApp/Media", "Android/media/com.whatsapp.w4b/WhatsApp Business/Media")

    fun whatsappJunk(): List<ScanFile> {
        val out = ArrayList<ScanFile>()
        whatsappRoots.map { resolve(it) }.filter { it.isDirectory }.forEach { root ->
            whatsappJunkDirs.map { File(root, it) }.filter { it.isDirectory }.forEach { d ->
                d.walkTopDown().filter { it.isFile }.forEach { out += ScanFile(it.absolutePath, it.length(), it.lastModified(), Category.of(it.name)) }
            }
        }
        return out
    }

    fun analyze(force: Boolean = false): CleanupAnalysis {
        if (!force) analysis?.let { return it }
        val files = scan(force)
        val now = System.currentTimeMillis()
        val a = CleanupAnalysis(
            files = files,
            duplicates = findDuplicates(files),
            oldVideos = files.filter { it.category == Category.VIDEOS && now - it.modified > OLD_VIDEO_MS }.sortedByDescending { it.size },
            large = files.filter { it.size >= LARGE_BYTES }.sortedByDescending { it.size },
            whatsappJunk = whatsappJunk()
        )
        analysis = a
        return a
    }

    /** Permanently deletes [list]. Returns (files removed, bytes freed). */
    fun delete(ctx: Context, list: List<ScanFile>): Pair<Int, Long> {
        var n = 0; var bytes = 0L
        val gone = ArrayList<String>()
        list.forEach { sf ->
            val f = File(sf.path)
            val len = f.length()
            if (f.delete() || !f.exists()) { n++; bytes += len; gone += sf.path }
        }
        if (gone.isNotEmpty()) runCatching { MediaScannerConnection.scanFile(ctx.applicationContext, gone.toTypedArray(), null, null) }
        invalidate()
        return n to bytes
    }

    fun deviceStorage(): Pair<Long, Long>? = runCatching {
        val s = StatFs(externalRoot().path); s.totalBytes to s.availableBytes
    }.getOrNull()
}

/** Folders shown under "Quick access" with live file counts. */
object QuickAccess {
    data class Target(val name: String, val dirs: List<String>)
    val targets = listOf(
        Target("WhatsApp", listOf("Android/media/com.whatsapp/WhatsApp", "WhatsApp")),
        Target("Telegram", listOf("Telegram", "Android/media/org.telegram.messenger/Telegram")),
        Target("Screenshots", listOf("Pictures/Screenshots", "DCIM/Screenshots", "Screenshots")),
        Target("Downloads", listOf("Download")),
        Target("Recorder", listOf("Recordings", "Record", "Recorder", "Sounds", "Music/Recordings")),
        Target("Bluetooth", listOf("Bluetooth", "Download/Bluetooth"))
    )
    fun firstExisting(t: Target): File? = t.dirs.map { StorageScanner.resolve(it) }.firstOrNull { it.isDirectory }
}
