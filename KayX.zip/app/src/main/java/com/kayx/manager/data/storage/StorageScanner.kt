package com.kayx.manager.data.storage

import android.content.Context
import android.provider.MediaStore
import com.kayx.manager.domain.model.FileItem
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

class StorageScanner(private val context: Context) {

    // Fast Document & File scanning using MediaStore API (No heavy recursive traversal)
    suspend fun scanDocuments(): List<FileItem> = withContext(Dispatchers.IO) {
        val fileList = mutableListOf<FileItem>()
        val collection = MediaStore.Files.getContentUri("external")
        
        val projection = arrayOf(
            MediaStore.Files.FileColumns._ID,
            MediaStore.Files.FileColumns.DISPLAY_NAME,
            MediaStore.Files.FileColumns.DATA,
            MediaStore.Files.FileColumns.SIZE,
            MediaStore.Files.FileColumns.DATE_MODIFIED,
            MediaStore.Files.FileColumns.MIME_TYPE
        )

        // Exclude images and videos if scanning for general documents/archives
        val selection = "${MediaStore.Files.FileColumns.MIME_TYPE} NOT LIKE ? AND ${MediaStore.Files.FileColumns.MIME_TYPE} NOT LIKE ?"
        val selectionArgs = arrayOf("image/%", "video/%")

        context.contentResolver.query(
            collection,
            projection,
            selection,
            selectionArgs,
            "${MediaStore.Files.FileColumns.DATE_MODIFIED} DESC"
        )?.use { cursor ->
            val nameColumn = cursor.getColumnIndexOrThrow(MediaStore.Files.FileColumns.DISPLAY_NAME)
            val pathColumn = cursor.getColumnIndexOrThrow(MediaStore.Files.FileColumns.DATA)
            val sizeColumn = cursor.getColumnIndexOrThrow(MediaStore.Files.FileColumns.SIZE)
            val dateColumn = cursor.getColumnIndexOrThrow(MediaStore.Files.FileColumns.DATE_MODIFIED)

            while (cursor.moveToNext()) {
                val name = cursor.getString(nameColumn) ?: continue
                val path = cursor.getString(pathColumn) ?: continue
                val size = cursor.getLong(sizeColumn)
                val date = cursor.getLong(dateColumn)

                val file = File(path)
                if (file.exists()) {
                    fileList.add(
                        FileItem(
                            name = name,
                            path = path,
                            size = size,
                            lastModified = date * 1000,
                            isDirectory = file.isDirectory
                        )
                    )
                }
            }
        }
        return@withContext fileList
    }

    // Fast APK Scanner using MediaStore
    suspend fun scanApks(): List<FileItem> = withContext(Dispatchers.IO) {
        val fileList = mutableListOf<FileItem>()
        val collection = MediaStore.Files.getContentUri("external")
        
        val projection = arrayOf(
            MediaStore.Files.FileColumns._ID,
            MediaStore.Files.FileColumns.DISPLAY_NAME,
            MediaStore.Files.FileColumns.DATA,
            MediaStore.Files.FileColumns.SIZE,
            MediaStore.Files.FileColumns.DATE_MODIFIED
        )

        val selection = "${MediaStore.Files.FileColumns.DATA} LIKE ?"
        val selectionArgs = arrayOf("%.apk")

        context.contentResolver.query(
            collection,
            projection,
            selection,
            selectionArgs,
            "${MediaStore.Files.FileColumns.DATE_MODIFIED} DESC"
        )?.use { cursor ->
            val nameColumn = cursor.getColumnIndexOrThrow(MediaStore.Files.FileColumns.DISPLAY_NAME)
            val pathColumn = cursor.getColumnIndexOrThrow(MediaStore.Files.FileColumns.DATA)
            val sizeColumn = cursor.getColumnIndexOrThrow(MediaStore.Files.FileColumns.SIZE)
            val dateColumn = cursor.getColumnIndexOrThrow(MediaStore.Files.FileColumns.DATE_MODIFIED)

            while (cursor.moveToNext()) {
                val name = cursor.getString(nameColumn) ?: continue
                val path = cursor.getString(pathColumn) ?: continue
                val size = cursor.getLong(sizeColumn)
                val date = cursor.getLong(dateColumn)

                val file = File(path)
                if (file.exists()) {
                    fileList.add(
                        FileItem(
                            name = name,
                            path = path,
                            size = size,
                            lastModified = date * 1000,
                            isDirectory = false
                        )
                    )
                }
            }
        }
        return@withContext fileList
    }
}
