package com.kayx.manager

import android.app.Application
import com.kayx.manager.data.settings.SettingsStore

class KayXApp : Application() {
    override fun onCreate() {
        super.onCreate()
        SettingsStore.init(this)
    }
}
