package com.kayx.manager.feature.filebrowser
import com.kayx.manager.ui.theme.Fg

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.ui.platform.LocalContext
import com.kayx.manager.data.archive.MultiExtract
import com.kayx.manager.data.filesystem.ExternalOps
import java.io.File
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.kayx.manager.data.settings.SettingsStore
import com.kayx.manager.domain.model.FileItem
import com.kayx.manager.domain.model.SortBy
import com.kayx.manager.domain.model.Tool
import com.kayx.manager.ui.glass.GlassCard
import com.kayx.manager.ui.glass.glassBackground
import com.kayx.manager.ui.theme.Accent
import java.text.DateFormat
import java.util.Date

private sealed interface Dlg {
    data object NewFolder : Dlg
    data object NewFile : Dlg
    data class Rename(val path: String, val name: String) : Dlg
    data object Delete : Dlg
    data object Zip : Dlg
    data object Batch : Dlg
    data object Pattern : Dlg
    data class Symlink(val target: String) : Dlg
}

private fun fmtSize(b: Long): String {
    if (b < 1024) return "$b B"
    val u = arrayOf("KB", "MB", "GB", "TB"); var v = b / 1024.0; var i = 0
    while (v >= 1024 && i < u.lastIndex) { v /= 1024; i++ }
    return "%.1f %s".format(v, u[i])
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FileBrowserScreen(startPath: String, onExit: () -> Unit, onOpenFile: (String, Tool) -> Unit, onSettings: () -> Unit = {}, vm: FileBrowserViewModel = viewModel()) {
    val s by vm.state.collectAsStateWithLifecycle()
    var dlg by remember { mutableStateOf<Dlg?>(null) }
    var menu by remember { mutableStateOf(false) }
    var openFor by remember { mutableStateOf<FileItem?>(null) }
    var infoFor by remember { mutableStateOf<FileItem?>(null) }
    val ctx = LocalContext.current
    val snack = remember { SnackbarHostState() }
    LaunchedEffect(startPath) { vm.start(startPath) }
    LaunchedEffect(Unit) { vm.syncDefaults() }
    LaunchedEffect(s.message) { s.message?.let { snack.showSnackbar(it); vm.consumeMessage() } }
    BackHandler { if (!vm.up()) onExit() }

    Scaffold(
        modifier = Modifier.glassBackground(), containerColor = Color.Transparent,
        snackbarHost = { SnackbarHost(snack) },
        floatingActionButton = {
            if (s.selected.isEmpty() && s.clipboard.isEmpty()) Column(horizontalAlignment = Alignment.End, verticalArrangement = Arrangement.spacedBy(10.dp)) {
                SmallFloatingActionButton(onClick = { dlg = Dlg.NewFile }, containerColor = Fg.copy(.15f)) { Icon(Icons.Default.NoteAdd, null) }
                FloatingActionButton(onClick = { dlg = Dlg.NewFolder }, containerColor = Accent) { Icon(Icons.Default.CreateNewFolder, null, tint = Color.Black) }
            }
        },
        topBar = {
            GlassCard(Modifier.statusBarsPadding().padding(12.dp).fillMaxWidth()) {
                Row(Modifier.padding(horizontal = 6.dp, vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                    IconButton({ if (!vm.up()) onExit() }) { Icon(Icons.Default.ArrowBack, null) }
                    if (s.searching) TextField(
                        s.query, vm::setQuery, Modifier.weight(1f), singleLine = true, placeholder = { Text(if (s.grep) "Search text inside files" else "Search in folder") },
                        colors = TextFieldDefaults.colors(focusedContainerColor = Color.Transparent, unfocusedContainerColor = Color.Transparent,
                            focusedIndicatorColor = Color.Transparent, unfocusedIndicatorColor = Color.Transparent))
                    else Column(Modifier.weight(1f)) {
                        val activePath = if (s.dualPane && s.activePane == 1) s.secondaryDir else s.dir
                        Text(if (s.selected.isEmpty()) activePath.substringAfterLast('/').ifEmpty { "/" } else "${s.selected.size} selected", maxLines = 1, style = MaterialTheme.typography.titleMedium)
                        BreadcrumbBar(if (s.dualPane && s.activePane == 1) s.secondaryDir else s.dir) { vm.openActive(it) }
                        val shownItems = if (s.dualPane && s.activePane == 1) s.secondaryItems else s.items
                        val disk = remember(s.dir, s.items.size) { runCatching { android.os.StatFs(android.os.Environment.getExternalStorageDirectory().path).let { it.totalBytes to (it.totalBytes - it.availableBytes) } }.getOrNull() }
                        Text("Folders: ${shownItems.count { it.isDir }}  Files: ${shownItems.count { !it.isDir }}" + (disk?.let { "  Disk: ${fmtSize(it.second)}/${fmtSize(it.first)}" } ?: ""),
                            maxLines = 1, style = MaterialTheme.typography.labelSmall, color = Fg.copy(.5f))
                    }
                    if (s.selected.isEmpty()) {
                        IconButton(vm::toggleDualPane) { Icon(if (s.dualPane) Icons.Default.ViewAgenda else Icons.Default.ViewColumn, "Toggle dual pane") }
                        IconButton(vm::toggleSearch) { Icon(if (s.searching) Icons.Default.Close else Icons.Default.Search, null) }
                        Box {
                            IconButton({ menu = true }) { Icon(Icons.Default.MoreVert, null) }
                            DropdownMenu(menu, { menu = false }) {
                                DropdownMenuItem({ Text(if (s.showHidden) "Hide hidden files" else "Show hidden files") }, { vm.toggleHidden(); menu = false })
                                if (s.dualPane) DropdownMenuItem({ Text("Swap panes") }, { vm.swapPanes(); menu = false })
                                DropdownMenuItem({ Text(if (s.grep) "Search by file name" else "Search inside files") }, { vm.toggleGrep(); menu = false })
                                DropdownMenuItem({ Text("Select all") }, { vm.selectAll(); menu = false })
                                DropdownMenuItem({ Text("Open terminal here") }, { menu = false; onOpenFile(if (s.dualPane && s.activePane == 1) s.secondaryDir else s.dir, Tool.TERMINAL) })
                                DropdownMenuItem({ Text("Recycle bin") }, { menu = false; onOpenFile("", Tool.RECYCLE) })
                                DropdownMenuItem({ Text("Set as Home") }, {
                                    SettingsStore.updateHomePath(if (s.dualPane && s.activePane == 1) s.secondaryDir else s.dir); vm.notify("Home folder set"); menu = false
                                })
                                DropdownMenuItem({ Text("Refresh") }, { vm.reload(); menu = false })
                                DropdownMenuItem({ Text("Add bookmark") }, {
                                    val here = if (s.dualPane && s.activePane == 1) s.secondaryDir else s.dir
                                    vm.notify(if (SettingsStore.addBookmark(here)) "Bookmark added" else "Already bookmarked"); menu = false
                                })
                                DropdownMenuItem({ Text("Settings") }, { onSettings(); menu = false })
                                DropdownMenuItem({ Text("Exit") }, { menu = false; onExit() })
                                SortBy.values().forEach { b -> DropdownMenuItem({ Text("Sort: ${b.name.lowercase()}" + if (s.sort == b) "  ✓" else "") }, { vm.setSort(b); menu = false }) }
                            }
                        }
                    } else {
                        IconButton(vm::selectAll) { Icon(Icons.Default.SelectAll, null) }
                        IconButton(vm::clearSelection) { Icon(Icons.Default.Close, null) }
                    }
                }
            }
        },
        bottomBar = {
            if (s.selected.isNotEmpty()) GlassCard(Modifier.navigationBarsPadding().padding(12.dp).fillMaxWidth()) {
                Row(Modifier.fillMaxWidth().padding(4.dp), horizontalArrangement = Arrangement.SpaceEvenly) {
                    IconButton({ vm.copySelected(false) }) { Icon(Icons.Default.ContentCopy, null) }
                    IconButton({ vm.copySelected(true) }) { Icon(Icons.Default.ContentCut, null) }
                    IconButton({ dlg = Dlg.Zip }) { Icon(Icons.Default.Archive, null) }
                    if (s.selected.size == 1) IconButton({ val p = s.selected.first(); dlg = Dlg.Rename(p, p.substringAfterLast('/')) }) { Icon(Icons.Default.Edit, null) }
                    var more by remember { mutableStateOf(false) }
                    Box {
                        IconButton({ more = true }) { Icon(Icons.Default.MoreVert, null) }
                        DropdownMenu(more, { more = false }) {
                            DropdownMenuItem({ Text("Invert selection") }, { vm.invertSelection(); more = false })
                            DropdownMenuItem({ Text("Select by pattern…") }, { dlg = Dlg.Pattern; more = false })
                            DropdownMenuItem({ Text("Batch rename…") }, { dlg = Dlg.Batch; more = false })
                            DropdownMenuItem({ Text("Duplicate") }, { vm.duplicateSelected(); more = false })
                            DropdownMenuItem({ Text("Share") }, { ExternalOps.share(ctx, s.selected.map(::File).filter { it.isFile }); more = false })
                            DropdownMenuItem({ Text("Copy path") }, { ExternalOps.copyText(ctx, s.selected.joinToString("\n")); vm.notify("Path copied"); more = false })
                            if (s.selected.size == 1) {
                                val one = s.selected.first()
                                DropdownMenuItem({ Text("Properties / permissions") }, {
                                    infoFor = (s.items + s.secondaryItems).firstOrNull { it.path == one }; more = false
                                })
                                DropdownMenuItem({ Text("Create symlink here…") }, { dlg = Dlg.Symlink(one); more = false })
                                if (MultiExtract.canExtract(one)) DropdownMenuItem({ Text("Extract here") }, { vm.extractHere(one); vm.clearSelection(); more = false })
                            }
                        }
                    }
                    IconButton({ if (SettingsStore.confirmDelete) dlg = Dlg.Delete else vm.deleteSelected() }) { Icon(Icons.Default.Delete, null, tint = Color(0xFFFF6B6B)) }
                }
            } else if (s.clipboard.isNotEmpty()) GlassCard(Modifier.navigationBarsPadding().padding(12.dp).fillMaxWidth()) {
                Row(Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text("${s.clipboard.size} item(s) ${if (s.cut) "to move" else "to copy"}", Modifier.weight(1f))
                    TextButton(vm::clearClipboard) { Text("Cancel") }
                    Button(vm::paste) { Icon(Icons.Default.ContentPaste, null); Spacer(Modifier.width(6.dp)); Text("Paste") }
                }
            }
        }
    ) { pad ->
        if (s.dualPane) {
            Row(Modifier.fillMaxSize().padding(top = pad.calculateTopPadding() + 4.dp, bottom = pad.calculateBottomPadding() + 90.dp)) {
                FileListPane(
                    path = s.dir, items = s.items, selected = s.selected, active = s.activePane == 0,
                    modifier = Modifier.weight(1f), onActivate = { vm.setActivePane(0) },
                    onItemClick = { f -> vm.setActivePane(0); if (s.selected.isNotEmpty()) vm.toggleSelect(f.path) else if (f.isDir) vm.openActive(f.path) else openFor = f },
                    onLong = { f -> vm.setActivePane(0); vm.toggleSelect(f.path) }
                )
                Divider(color = Fg.copy(.16f), modifier = Modifier.width(1.dp).fillMaxHeight())
                FileListPane(
                    path = s.secondaryDir, items = s.secondaryItems, selected = s.selected, active = s.activePane == 1,
                    modifier = Modifier.weight(1f), onActivate = { vm.setActivePane(1) },
                    onItemClick = { f -> vm.setActivePane(1); if (s.selected.isNotEmpty()) vm.toggleSelect(f.path) else if (f.isDir) vm.openActive(f.path) else openFor = f },
                    onLong = { f -> vm.setActivePane(1); vm.toggleSelect(f.path) }
                )
            }
        } else {
            if (s.items.isEmpty() && !s.loading) Box(Modifier.fillMaxSize().padding(pad), Alignment.Center) { Text("Empty", color = Fg.copy(.5f)) }
            FileListPane(
                path = s.dir, items = s.items, selected = s.selected, active = true,
                modifier = Modifier.fillMaxSize().padding(top = pad.calculateTopPadding() + 4.dp, bottom = pad.calculateBottomPadding() + 90.dp),
                onActivate = { vm.setActivePane(0) },
                onItemClick = { f -> if (s.selected.isNotEmpty()) vm.toggleSelect(f.path) else if (f.isDir) vm.openActive(f.path) else openFor = f },
                onLong = { f -> vm.toggleSelect(f.path) }
            )
        }
    }

    when (val d = dlg) {
        is Dlg.NewFolder -> NameDialog("New folder", "", { dlg = null }) { vm.newFolder(it); dlg = null }
        is Dlg.NewFile -> NameDialog("New file", "", { dlg = null }) { vm.newFile(it); dlg = null }
        is Dlg.Rename -> NameDialog("Rename", d.name, { dlg = null }) { vm.rename(d.path, it); dlg = null }
        is Dlg.Zip -> NameDialog("Create ZIP", "archive.zip", { dlg = null }) { vm.zipSelected(it); dlg = null }
        is Dlg.Delete -> AlertDialog({ dlg = null }, title = { Text("Delete ${s.selected.size} item(s)?") }, text = { Text("This cannot be undone.") },
            confirmButton = { TextButton({ vm.deleteSelected(); dlg = null }) { Text("Delete", color = Color(0xFFFF6B6B)) } },
            dismissButton = { TextButton({ dlg = null }) { Text("Cancel") } })
        is Dlg.Batch -> BatchRenameDialog(s.selected.size, { dlg = null }) { f, r, rx, st -> vm.batchRename(f, r, rx, st); dlg = null }
        is Dlg.Pattern -> NameDialog("Select by pattern (e.g. *.jpg)", "*.", { dlg = null }) { vm.selectPattern(it); dlg = null }
        is Dlg.Symlink -> NameDialog("Symlink name", d.target.substringAfterLast('/') + "_link", { dlg = null }) { vm.symlink(d.target, it); dlg = null }
        null -> {}
    }
    if (s.conflicts.isNotEmpty()) ConflictDialog(s.conflicts, { vm.paste(it) }, vm::dismissConflicts)
    openFor?.let { f -> OpenWithDialog(f, vm, onOpenFile, { infoFor = f }, { openFor = null }) }
    infoFor?.let { f -> PropertiesDialog(f, { infoFor = null }, vm::reload) }
}

@Composable
private fun FileListPane(
    path: String,
    items: List<FileItem>,
    selected: Set<String>,
    active: Boolean,
    modifier: Modifier = Modifier,
    onActivate: () -> Unit,
    onItemClick: (FileItem) -> Unit,
    onLong: (FileItem) -> Unit
) {
    Column(modifier) {
        Surface(
            onClick = onActivate,
            color = if (active) Accent.copy(.18f) else Fg.copy(.045f),
            shape = androidx.compose.foundation.shape.RoundedCornerShape(9.dp),
            modifier = Modifier.fillMaxWidth().padding(horizontal = 5.dp, vertical = 4.dp)
        ) {
            Text(path.substringAfterLast('/').ifEmpty { "/" }, Modifier.padding(horizontal = 9.dp, vertical = 7.dp),
                maxLines = 1, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.labelMedium)
        }
        if (items.isEmpty()) Box(Modifier.fillMaxWidth().weight(1f), Alignment.Center) {
            Text("Empty", color = Fg.copy(.42f), style = MaterialTheme.typography.labelSmall)
        } else LazyColumn(
            Modifier.fillMaxWidth().weight(1f),
            contentPadding = PaddingValues(horizontal = 5.dp, vertical = 4.dp),
            verticalArrangement = Arrangement.spacedBy(3.dp)
        ) {
            items(items, key = { it.path }) { f ->
                FileRow(f, f.path in selected, onClick = { onItemClick(f) }, onLong = { onLong(f) })
            }
        }
    }
}

@Composable
private fun FileRow(f: FileItem, selected: Boolean, onClick: () -> Unit, onLong: () -> Unit) {
    val folder = f.isDir
    GlassCard(
        Modifier.fillMaxWidth(),
        shape = androidx.compose.foundation.shape.RoundedCornerShape(11.dp),
        tint = if (selected) Accent else Fg,
        onClick = onClick,
        onLongClick = onLong
    ) {
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 11.dp, vertical = 9.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                when {
                    selected -> Icons.Default.CheckCircle
                    folder -> Icons.Default.Folder
                    f.name.endsWith(".apk", true) -> Icons.Default.Android
                    f.name.endsWith(".zip", true) || f.name.endsWith(".7z", true) || f.name.endsWith(".rar", true) -> Icons.Default.Archive
                    f.name.endsWith(".jpg", true) || f.name.endsWith(".png", true) || f.name.endsWith(".webp", true) -> Icons.Default.Image
                    else -> Icons.Default.InsertDriveFile
                },
                contentDescription = null,
                tint = if (selected || folder) Accent else Fg.copy(.78f),
                modifier = Modifier.size(23.dp)
            )
            Spacer(Modifier.width(11.dp))
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                Text(f.name, maxLines = 1, overflow = TextOverflow.Ellipsis,
                    style = MaterialTheme.typography.bodyMedium, color = Fg)
                Text(
                    (if (folder) "Folder" else fmtSize(f.size)) + "  ·  " + DateFormat.getDateInstance(DateFormat.MEDIUM).format(Date(f.modified)),
                    style = MaterialTheme.typography.labelSmall, color = Fg.copy(.53f), maxLines = 1
                )
            }
            if (folder) Icon(Icons.Default.ChevronRight, null, tint = Fg.copy(.38f), modifier = Modifier.size(18.dp))
            else if (!selected) Icon(Icons.Default.MoreVert, null, tint = Fg.copy(.35f), modifier = Modifier.size(18.dp))
        }
    }
}

@Composable
private fun NameDialog(title: String, initial: String, onDismiss: () -> Unit, onOk: (String) -> Unit) {
    var t by remember { mutableStateOf(initial) }
    AlertDialog(onDismiss, title = { Text(title) }, text = { OutlinedTextField(t, { t = it }, singleLine = true) },
        confirmButton = { TextButton({ onOk(t) }) { Text("OK") } }, dismissButton = { TextButton(onDismiss) { Text("Cancel") } })
}
