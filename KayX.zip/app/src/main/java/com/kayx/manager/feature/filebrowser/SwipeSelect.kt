package com.kayx.manager.feature.filebrowser

import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.runtime.getValue
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.ui.Modifier
import androidx.compose.ui.composed
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.unit.dp
import kotlin.math.abs

/** Swiping a row left or right (past ~48dp) fires [onSwipe] once per gesture. Vertical scrolling and taps are unaffected. */
internal fun Modifier.swipeToSelect(enabled: Boolean, onSwipe: () -> Unit): Modifier = composed {
    val current by rememberUpdatedState(onSwipe)
    pointerInput(enabled) {
        if (!enabled) return@pointerInput
        val threshold = 48.dp.toPx()
        var total = 0f
        var fired = false
        detectHorizontalDragGestures(
            onDragStart = { total = 0f; fired = false },
            onHorizontalDrag = { change, dx ->
                total += dx
                if (!fired && abs(total) > threshold) { fired = true; change.consume(); current() }
            }
        )
    }
}
