package com.kayx.manager.data.archive

import android.content.Context
import java.io.BufferedOutputStream
import java.io.File
import java.io.FileOutputStream
import java.io.FilterOutputStream
import java.io.OutputStream
import java.util.zip.CRC32
import java.util.zip.ZipEntry
import java.util.zip.ZipFile
import java.util.zip.ZipOutputStream

/** Separator used to address "<archive>::kx::<entry>" as one string. */
const val ZIP_SEP = "::kx::"

/** In-place ZIP/APK editing. Rewrites keep STORED entries STORED and zipalign them (4 bytes, .so = 4096). */
object ArchiveEdit {
    private class Counting(out: OutputStream) : FilterOutputStream(out) {
        var count = 0L
        override fun write(b: Int) { out.write(b); count++ }
        override fun write(b: ByteArray, off: Int, len: Int) { out.write(b, off, len); count += len }
    }

    private fun hit(selected: String, name: String): Boolean {
        val n = selected.trimEnd('/')
        return name == n || name == "$n/" || name.startsWith("$n/")
    }

    fun readEntry(zip: File, name: String): ByteArray = ZipFile(zip).use { z ->
        val e = z.getEntry(name) ?: error("Entry not found: $name")
        z.getInputStream(e).use { it.readBytes() }
    }

    fun extractToCache(ctx: Context, zip: File, name: String): File {
        val out = File(ctx.cacheDir, "zipview/${zip.absolutePath.hashCode()}/$name")
        out.parentFile?.mkdirs()
        out.writeBytes(readEntry(zip, name))
        return out
    }

    private fun pad(offset: Long, name: String, page: Boolean): ByteArray? {
        val align = if (page) 4096 else 4
        val nameLen = name.toByteArray(Charsets.UTF_8).size
        var p = ((align - ((offset + 30 + nameLen) % align)) % align).toInt()
        if (p == 0) return null
        if (p < 4) p += align
        val b = ByteArray(p)
        b[0] = 0x35; b[1] = 0xD9.toByte()
        b[2] = ((p - 4) and 0xFF).toByte(); b[3] = (((p - 4) shr 8) and 0xFF).toByte()
        return b
    }

    private fun putStored(zos: ZipOutputStream, cnt: Counting, name: String, size: Long, crc: Long, time: Long, data: () -> java.io.InputStream) {
        val ze = ZipEntry(name)
        ze.method = ZipEntry.STORED; ze.size = size; ze.compressedSize = size; ze.crc = crc
        if (time > 0) ze.time = time
        zos.closeEntry()
        ze.extra = pad(cnt.count, name, name.endsWith(".so"))
        zos.putNextEntry(ze)
        data().use { it.copyTo(zos) }
        zos.closeEntry()
    }

    private fun putBytes(zos: ZipOutputStream, cnt: Counting, name: String, stored: Boolean, bytes: ByteArray, time: Long) {
        if (stored) {
            val crc = CRC32().apply { update(bytes) }.value
            putStored(zos, cnt, name, bytes.size.toLong(), crc, time) { bytes.inputStream() }
        } else {
            val ze = ZipEntry(name); if (time > 0) ze.time = time
            zos.putNextEntry(ze); zos.write(bytes); zos.closeEntry()
        }
    }

    /**
     * Rewrites [zip] atomically. [delete] removes entries/folders, [replace] swaps content of existing entries,
     * [rename] renames entries/folders, [add] adds new entries (or replaces if present). Returns number of removed entries.
     * With all maps empty this simply re-aligns the archive (zipalign).
     */
    fun rewrite(
        zip: File, delete: Set<String> = emptySet(), replace: Map<String, ByteArray> = emptyMap(),
        rename: Map<String, String> = emptyMap(), add: Map<String, ByteArray> = emptyMap()
    ): Result<Int> = runCatching {
        val tmp = File(zip.parentFile, zip.name + ".kayx-tmp")
        tmp.delete()
        var removed = 0
        try {
            ZipFile(zip).use { src ->
                val cnt = Counting(BufferedOutputStream(FileOutputStream(tmp), 1 shl 16))
                ZipOutputStream(cnt).use { zos ->
                    val written = HashSet<String>()
                    val en = src.entries()
                    while (en.hasMoreElements()) {
                        val e = en.nextElement()
                        if (delete.any { hit(it, e.name) }) { removed++; continue }
                        var name = e.name
                        for ((old, new) in rename) {
                            val o = old.trimEnd('/'); val nn = new.trimEnd('/')
                            if (name == o) name = nn else if (name.startsWith("$o/")) name = nn + name.substring(o.length)
                        }
                        if (!written.add(name)) continue
                        val rep = replace[e.name] ?: add[e.name]
                        when {
                            rep != null -> putBytes(zos, cnt, name, e.method == ZipEntry.STORED, rep, e.time)
                            e.isDirectory -> { zos.closeEntry(); zos.putNextEntry(ZipEntry(name).apply { if (e.time > 0) time = e.time }); zos.closeEntry() }
                            e.method == ZipEntry.STORED -> putStored(zos, cnt, name, e.size, e.crc, e.time) { src.getInputStream(e) }
                            else -> {
                                zos.putNextEntry(ZipEntry(name).apply { if (e.time > 0) time = e.time })
                                src.getInputStream(e).use { it.copyTo(zos) }; zos.closeEntry()
                            }
                        }
                    }
                    for ((n, b) in add) if (written.add(n)) putBytes(zos, cnt, n, n.endsWith(".arsc"), b, System.currentTimeMillis())
                }
            }
            check(tmp.renameTo(zip)) { "Could not replace original archive" }
        } catch (t: Throwable) { tmp.delete(); throw t }
        removed
    }
}
