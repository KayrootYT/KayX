package com.kayx.manager.data.storage

import android.content.Context
import android.content.SharedPreferences
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import java.io.File
import java.security.MessageDigest
import java.security.SecureRandom

/** User tags (label -> file paths), persisted in SharedPreferences. Compose-observable. */
object TagStore {
    private var prefs: SharedPreferences? = null
    var tags by mutableStateOf(mapOf<String, List<String>>())
        private set

    fun init(ctx: Context) {
        val p = ctx.applicationContext.getSharedPreferences("kayx_tags", Context.MODE_PRIVATE)
        prefs = p
        val m = LinkedHashMap<String, MutableList<String>>()
        (p.getString("tags", "") ?: "").lineSequence().forEach { l ->
            val i = l.indexOf('\t')
            if (i > 0) m.getOrPut(l.substring(0, i)) { ArrayList() } += l.substring(i + 1)
        }
        tags = m
    }

    private fun persist() {
        prefs?.edit()?.putString("tags", tags.entries.joinToString("\n") { (t, ps) -> ps.joinToString("\n") { "$t\t$it" } })?.apply()
    }

    fun add(tag: String, paths: Collection<String>) {
        val t = tag.trim().replace('\t', ' ').replace('\n', ' ')
        if (t.isEmpty()) return
        val m = tags.toMutableMap()
        m[t] = (m[t].orEmpty() + paths).distinct()
        tags = m; persist()
    }

    fun remove(tag: String, path: String) {
        val m = tags.toMutableMap()
        val l = m[tag].orEmpty() - path
        if (l.isEmpty()) m.remove(tag) else m[tag] = l
        tags = m; persist()
    }

    fun deleteTag(tag: String) { tags = tags - tag; persist() }

    /** Tagged files that still exist. */
    fun files(tag: String): List<ScanFile> = tags[tag].orEmpty().map(::File).filter { it.isFile }
        .map { ScanFile(it.absolutePath, it.length(), it.lastModified(), Category.of(it.name)) }

    fun totalFiles(): Int = tags.values.flatten().distinct().count { File(it).exists() }
}

/** PIN-protected private folder stored in the app's own storage (invisible to other apps). */
object PrivateSpace {
    private fun prefs(ctx: Context) = ctx.applicationContext.getSharedPreferences("kayx_private", Context.MODE_PRIVATE)

    fun dir(ctx: Context): File = File(ctx.applicationContext.filesDir, "private_space").apply { mkdirs() }
    fun hasPin(ctx: Context) = !prefs(ctx).getString("hash", null).isNullOrEmpty()
    fun fileCount(ctx: Context): Int = dir(ctx).walkTopDown().count { it.isFile }

    private fun hash(pin: String, salt: String): String =
        MessageDigest.getInstance("SHA-256").digest((salt + pin).toByteArray()).joinToString("") { "%02x".format(it) }

    fun setPin(ctx: Context, pin: String) {
        val salt = ByteArray(12).also { SecureRandom().nextBytes(it) }.joinToString("") { "%02x".format(it) }
        prefs(ctx).edit().putString("salt", salt).putString("hash", hash(pin, salt)).apply()
    }

    fun verify(ctx: Context, pin: String): Boolean {
        val p = prefs(ctx)
        val salt = p.getString("salt", "") ?: ""
        return p.getString("hash", null) == hash(pin, salt)
    }
}
