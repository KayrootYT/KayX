KayX Extra 3D Icons — Android resources

Copy/extract drawable-nodpi/ into:
app/src/main/res/drawable-nodpi/

Home / Quick Access (256x256 WebP):
  kayx_extra_recently_deleted
  kayx_extra_recorder
  kayx_extra_root_directory
  kayx_extra_music
  kayx_extra_pictures
  kayx_extra_whatsapp
  kayx_extra_movies
  kayx_extra_downloads
  kayx_extra_screenshots
  kayx_extra_dcim
  kayx_extra_cross_device
  kayx_extra_documents_folder

Bottom navigation (128x128 WebP):
  kayx_extra_nav_tools
  kayx_extra_nav_storage
  kayx_extra_nav_settings
  kayx_extra_nav_files

Integration notes:
- These are additive resources; no existing drawable is overwritten.
- Keep existing Light/Dark/AMOLED theme colors and settings unchanged.
- Suggested Home icon display size: 40–48dp (same size for all category/quick-access icons).
- Suggested bottom navigation artwork size: 28–32dp.
